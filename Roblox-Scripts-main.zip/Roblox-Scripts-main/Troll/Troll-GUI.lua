local UltimateTrollingGuiV6 = Instance.new("ScreenGui")
local Main = Instance.new("Frame")
local UIGradient = Instance.new("UIGradient")
local UICorner = Instance.new("UICorner")
local Title = Instance.new("TextLabel")
local SubTitle = Instance.new("TextLabel")
local Welcome2 = Instance.new("TextLabel")
local UICorner_2 = Instance.new("UICorner")
local ScrollSizer = Instance.new("Frame")
local ScrollingFrame = Instance.new("ScrollingFrame")
local kohls = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")
local Cleetus = Instance.new("TextButton")
local UICorner_4 = Instance.new("UICorner")
local JohnDoe = Instance.new("TextButton")
local UICorner_5 = Instance.new("UICorner")
local TheDankEngine = Instance.new("TextButton")
local UICorner_6 = Instance.new("UICorner")
local Banisher = Instance.new("TextButton")
local UICorner_7 = Instance.new("UICorner")
local Illuminati = Instance.new("TextButton")
local UICorner_8 = Instance.new("UICorner")
local MineCraftSteve = Instance.new("TextButton")
local UICorner_9 = Instance.new("UICorner")
local Goner = Instance.new("TextButton")
local UICorner_10 = Instance.new("UICorner")
local HolyWrench = Instance.new("TextButton")
local UICorner_11 = Instance.new("UICorner")
local Baseplate = Instance.new("TextButton")
local UICorner_12 = Instance.new("UICorner")
local FlingGUI = Instance.new("TextButton")
local UICorner_13 = Instance.new("UICorner")
local TOPk3k = Instance.new("TextButton")
local UICorner_14 = Instance.new("UICorner")
local KFC = Instance.new("TextButton")
local UICorner_15 = Instance.new("UICorner")
local TrollingGUI = Instance.new("TextButton")
local UICorner_16 = Instance.new("UICorner")
local InfYield = Instance.new("TextButton")
local UICorner_17 = Instance.new("UICorner")
local SuTart = Instance.new("TextButton")
local UICorner_18 = Instance.new("UICorner")
local Backrooms = Instance.new("TextButton")
local UICorner_19 = Instance.new("UICorner")
local NexPluviaAdmin = Instance.new("TextButton")
local UICorner_20 = Instance.new("UICorner")
local FunnyVest = Instance.new("TextButton")
local UICorner_21 = Instance.new("UICorner")
local Nuke = Instance.new("TextButton")
local UICorner_22 = Instance.new("UICorner")
local Stand = Instance.new("TextButton")
local UICorner_23 = Instance.new("UICorner")
local c00lify = Instance.new("TextButton")
local UICorner_24 = Instance.new("UICorner")
local clownvan = Instance.new("TextButton")
local UICorner_25 = Instance.new("UICorner")
local VrSword = Instance.new("TextButton")
local UICorner_26 = Instance.new("UICorner")
local ParkourGod = Instance.new("TextButton")
local UICorner_27 = Instance.new("UICorner")
local ServerAdmin = Instance.new("TextButton")
local UICorner_28 = Instance.new("UICorner")
local Sniper = Instance.new("TextButton")
local UICorner_29 = Instance.new("UICorner")
local ElioBlasio = Instance.new("TextButton")
local UICorner_30 = Instance.new("UICorner")
local Ender = Instance.new("TextButton")
local UICorner_31 = Instance.new("UICorner")
local BanHammer = Instance.new("TextButton")
local UICorner_32 = Instance.new("UICorner")
local Caducus = Instance.new("TextButton")
local UICorner_33 = Instance.new("UICorner")
local AK47 = Instance.new("TextButton")
local UICorner_34 = Instance.new("UICorner")
local Car = Instance.new("TextButton")
local UICorner_35 = Instance.new("UICorner")
local Carnage = Instance.new("TextButton")
local UICorner_36 = Instance.new("UICorner")
local MLG = Instance.new("TextButton")
local UICorner_37 = Instance.new("UICorner")
local Pen = Instance.new("TextButton")
local UICorner_38 = Instance.new("UICorner")
local Broomstick = Instance.new("TextButton")
local UICorner_39 = Instance.new("UICorner")
local Memeus = Instance.new("TextButton")
local UICorner_40 = Instance.new("UICorner")
local Xester = Instance.new("TextButton")
local UICorner_41 = Instance.new("UICorner")
local DistractDance = Instance.new("TextButton")
local UICorner_42 = Instance.new("UICorner")
local Goopie = Instance.new("TextButton")
local UICorner_43 = Instance.new("UICorner")
local Headless = Instance.new("TextButton")
local UICorner_44 = Instance.new("UICorner")
local OrangeJustice = Instance.new("TextButton")
local UICorner_45 = Instance.new("UICorner")
local InsanityPowers = Instance.new("TextButton")
local UICorner_46 = Instance.new("UICorner")
local Floss = Instance.new("TextButton")
local UICorner_47 = Instance.new("UICorner")
local HeadHold = Instance.new("TextButton")
local UICorner_48 = Instance.new("UICorner")
local RussainKick = Instance.new("TextButton")
local UICorner_49 = Instance.new("UICorner")
local Pillow = Instance.new("TextButton")
local UICorner_50 = Instance.new("UICorner")
local Pp = Instance.new("TextButton")
local UICorner_51 = Instance.new("UICorner")
local BlackHole = Instance.new("TextButton")
local UICorner_52 = Instance.new("UICorner")
local JhonDoe = Instance.new("TextButton")
local UICorner_53 = Instance.new("UICorner")
local VR = Instance.new("TextButton")
local UICorner_54 = Instance.new("UICorner")
local TouchKill = Instance.new("TextButton")
local UICorner_55 = Instance.new("UICorner")
local TakeTheL = Instance.new("TextButton")
local UICorner_56 = Instance.new("UICorner")
local Grabknife = Instance.new("TextButton")
local UICorner_57 = Instance.new("UICorner")
local Rtx = Instance.new("TextButton")
local UICorner_58 = Instance.new("UICorner")
local RainbowKing = Instance.new("TextButton")
local UICorner_59 = Instance.new("UICorner")
local Gun = Instance.new("TextButton")
local UICorner_60 = Instance.new("UICorner")
local PixelCar = Instance.new("TextButton")
local UICorner_61 = Instance.new("UICorner")
local HellRobotics = Instance.new("TextButton")
local UICorner_62 = Instance.new("UICorner")
local Titain = Instance.new("TextButton")
local UICorner_63 = Instance.new("UICorner")
local Neko = Instance.new("TextButton")
local UICorner_64 = Instance.new("UICorner")
local Zen = Instance.new("TextButton")
local UICorner_65 = Instance.new("UICorner")
local Minigun = Instance.new("TextButton")
local UICorner_66 = Instance.new("UICorner")
local Eggdog = Instance.new("TextButton")
local UICorner_67 = Instance.new("UICorner")
local Credits = Instance.new("TextLabel")
local UICorner_68 = Instance.new("UICorner")
local Respawn = Instance.new("TextButton")
local UICorner_69 = Instance.new("UICorner")
local Netless = Instance.new("TextButton")
local UICorner_70 = Instance.new("UICorner")
local AntiFling = Instance.new("TextBox")
local UICorner_71 = Instance.new("UICorner")
local X = Instance.new("TextButton")
local UICorner_72 = Instance.new("UICorner")
local OpenUtg = Instance.new("TextButton")
local subtext = Instance.new("TextLabel")

--Properties:

UltimateTrollingGuiV6.Name = "UltimateTrollingGuiV6"
UltimateTrollingGuiV6.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
UltimateTrollingGuiV6.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
UltimateTrollingGuiV6.ResetOnSpawn = true

Main.Name = "Main"
Main.Parent = UltimateTrollingGuiV6
Main.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Main.BorderSizePixel = 0
Main.Position = UDim2.new(0.382268965, 0, 1.18099999, 0)
Main.Size = UDim2.new(0, 451, 0, 534)

UIGradient.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(137, 0, 254)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(223, 0, 255))}
UIGradient.Parent = Main

UICorner.Parent = Main
UICorner.CornerRadius = UDim.new(0, 9)

Title.Name = "Title"
Title.Parent = Main
Title.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Title.BackgroundTransparency = 1.000
Title.Position = UDim2.new(0.0600659028, 0, -0.00186577276, 0)
Title.Size = UDim2.new(0, 395, 0, 51)
Title.Font = Enum.Font.SourceSansBold
Title.Text = "ULTIMATE TROLLING GUI"
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.TextScaled = true
Title.TextSize = 14.000
Title.TextWrapped = true

SubTitle.Name = "SubTitle"
SubTitle.Parent = Main
SubTitle.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
SubTitle.BackgroundTransparency = 1.000
SubTitle.Position = UDim2.new(0.168713331, 0, 0.0599319786, 0)
SubTitle.Size = UDim2.new(0, 297, 0, 35)
SubTitle.Font = Enum.Font.SourceSans
SubTitle.Text = ""
SubTitle.TextColor3 = Color3.fromRGB(255, 255, 255)
SubTitle.TextScaled = true
SubTitle.TextSize = 14.000
SubTitle.TextWrapped = true

Welcome2.Name = "Welcome2"
Welcome2.Parent = Main
Welcome2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Welcome2.BorderSizePixel = 0
Welcome2.Position = UDim2.new(0.0245891828, 0, 0.114000015, 0)
Welcome2.Size = UDim2.new(0, 428, 0, 36)
Welcome2.Font = Enum.Font.SourceSansBold
Welcome2.Text = "DM me on discord yepimsirpwnsalot for sneak peeks!"
Welcome2.TextColor3 = Color3.fromRGB(0, 0, 0)
Welcome2.TextSize = 20.000

UICorner_2.CornerRadius = UDim.new(1, 0)
UICorner_2.Parent = Welcome2

ScrollSizer.Name = "ScrollSizer"
ScrollSizer.Parent = Main
ScrollSizer.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollSizer.BackgroundTransparency = 1.000
ScrollSizer.BorderSizePixel = 0
ScrollSizer.Position = UDim2.new(0.0245891828, 0, 0.196629211, 0)
ScrollSizer.Size = UDim2.new(0, 428, 2, 333)

local UICorner = Instance.new("UICorner")
UICorner.Parent = ScrollSizer
UICorner.CornerRadius = UDim.new(0, 9)

ScrollingFrame.Parent = ScrollSizer
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Size = UDim2.new(0, 427, 0, 333)
ScrollingFrame.ScrollBarThickness = 0

local UICorner = Instance.new("UICorner")
UICorner.Parent = ScrollingFrame
UICorner.CornerRadius = UDim.new(0, 9)

kohls.Name = "Kohl's Admin"
kohls.Parent = ScrollingFrame
kohls.BackgroundColor3 = Color3.fromRGB(0, 150, 255)
kohls.Position = UDim2.new(0.0093457941, 0, 0.0022281385, 0)
kohls.Size = UDim2.new(0, 419, 0, 36)
kohls.Font = Enum.Font.SourceSansBold
kohls.Text = "    Kohl's Admin"
kohls.TextColor3 = Color3.fromRGB(255, 255, 255)
kohls.TextSize = 20.000
kohls.TextWrapped = true
kohls.TextXAlignment = Enum.TextXAlignment.Left

UICorner_3.Parent = kohls

Cleetus.Name = "Cleetus"
Cleetus.Parent = ScrollingFrame
Cleetus.BackgroundColor3 = Color3.fromRGB(0, 150, 255)
Cleetus.Position = UDim2.new(0.0093457941, 0, 0.0175743196, 0)
Cleetus.Size = UDim2.new(0, 419, 0, 36)
Cleetus.Font = Enum.Font.SourceSansBold
Cleetus.Text = "    Cleetus"
Cleetus.TextColor3 = Color3.fromRGB(255, 255, 255)
Cleetus.TextSize = 20.000
Cleetus.TextWrapped = true
Cleetus.TextXAlignment = Enum.TextXAlignment.Left

UICorner_4.Parent = Cleetus

JohnDoe.Name = "JohnDoe"
JohnDoe.Parent = ScrollingFrame
JohnDoe.BackgroundColor3 = Color3.fromRGB(0, 150, 255)
JohnDoe.Position = UDim2.new(0.0093457941, 0, 0.0329205021, 0)
JohnDoe.Size = UDim2.new(0, 419, 0, 36)
JohnDoe.Font = Enum.Font.SourceSansBold
JohnDoe.Text = "    John Doe"
JohnDoe.TextColor3 = Color3.fromRGB(255, 255, 255)
JohnDoe.TextSize = 20.000
JohnDoe.TextWrapped = true
JohnDoe.TextXAlignment = Enum.TextXAlignment.Left

UICorner_5.Parent = JohnDoe

TheDankEngine.Name = "TheDankEngine"
TheDankEngine.Parent = ScrollingFrame
TheDankEngine.BackgroundColor3 = Color3.fromRGB(225, 193, 110)
TheDankEngine.Position = UDim2.new(0.0093457941, 0, 0.0482666828, 0)
TheDankEngine.Size = UDim2.new(0, 419, 0, 36)
TheDankEngine.Font = Enum.Font.SourceSansBold
TheDankEngine.Text = "    Thomas The Dank Engine"
TheDankEngine.TextColor3 = Color3.fromRGB(255, 255, 255)
TheDankEngine.TextSize = 20.000
TheDankEngine.TextWrapped = true
TheDankEngine.TextXAlignment = Enum.TextXAlignment.Left
TheDankEngine.MouseButton1Down:Connect(function()
-- ty krystalburger
--[[
    Thomas The Dank Engine:
                            By: KrystalTeam
                            Features: Being a dank engine that kill people
                            Version: 1.0.0.2
--]]

local p = game.Players.LocalPlayer.Character

local weld = Instance.new("Weld",p.Humanoid.Torso)
weld.Part0 = p.Humanoid.Torso

local train = Instance.new("Part",p.Humanoid.Torso)
train.Anchored = true
train.CanCollide = false
train.Size = Vector3.new(3,2,6)
train.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
weld.Part1 = train
weld.C1 = CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(180),0)
train.Anchored = false
local TrainMesh = Instance.new("SpecialMesh",train)
TrainMesh.MeshType = Enum.MeshType.FileMesh
TrainMesh.Scale = Vector3.new(0.020,0.020,0.015)
TrainMesh.MeshId = "rbxassetid://431017802"
TrainMesh.TextureId = "rbxassetid://431017809"


local weld2 = Instance.new("Weld",p.Humanoid.Torso)
weld2.Part0 = p.Humanoid.Torso
local Smoke = Instance.new("Part",p.Humanoid.Torso)
Smoke.Anchored = true
Smoke.CanCollide = false
Smoke.Size = Vector3.new(1,1,1)
Smoke.CustomPhysicalProperties = PhysicalProperties.new(0,0,0,0,0)
weld2.Part1 = Smoke
weld2.C1 = CFrame.new(0,-4,3.5)-- * CFrame.Angles(0,math.rad(180),0)
Smoke.Anchored = false
Smoke.Transparency = 1;

local Particle = Instance.new("ParticleEmitter",Smoke)
Particle.Rate = 50;
Particle.Speed = NumberRange.new(30,60);
Particle.VelocitySpread = 4;
Particle.Texture = "rbxassetid://133619974"

local Light = Instance.new("SpotLight",train)
Light.Angle = 45;
Light.Brightness = 100;
Light.Face = Enum.NormalId.Back;
Light.Range = 30;

p.Humanoid.WalkSpeed = 20;


for i,v in pairs(p:GetChildren()) do
    if v:IsA("Part") then
        v.Transparency = 1;
    elseif v:IsA("Hat") then
        v:Destroy()
    elseif v:IsA("Model") then
        v:Destroy()
    end
end

local function SFX(id) local s=Instance.new("Sound",p.Humanoid.Torso); s.SoundId = "rbxassetid://"..id; s.Volume = 1; return s; end
train.Touched:connect(function(p)
    if p.Parent then
        if p.Parent:IsA("Model") then
            if game.Players:FindFirstChild(p.Parent.Name) then
                if p.Parent.Name ~= game.Players.LocalPlayer.Name then
                    game.Players:FindFirstChild(p.Parent.Name).Character:BreakJoints()
                    local Whistle = SFX(604650009)
                    Whistle:Play()
                end
            end
        end
    end
end)
local sound   = Instance.new("Sound")
sound.SoundId = "http://www.roblox.com/asset/?id=198482531" --Change the last numbers of the link to the id of your audio.
sound.Parent  = game.Workspace
sound.Volume  = 200
sound.Looped  = true
sound:play()
repeat wait() until game.Players.LocalPlayer
local Mouse = game.Players.LocalPlayer:GetMouse()
local Plr = game.Players.LocalPlayer
Plr.Character.Humanoid.MaxHealth = math.huge 
Plr.Character.Humanoid.WalkSpeed = 100
end)

UICorner_6.Parent = TheDankEngine

Banisher.Name = "Banisher"
Banisher.Parent = ScrollingFrame
Banisher.BackgroundColor3 = Color3.fromRGB(225, 193, 110)
Banisher.Position = UDim2.new(0.0093457941, 0, 0.077888377, 0)
Banisher.Size = UDim2.new(0, 419, 0, 36)
Banisher.Font = Enum.Font.SourceSansBold
Banisher.Text = "    Banisher"
Banisher.TextColor3 = Color3.fromRGB(255, 255, 255)
Banisher.TextSize = 20.000
Banisher.TextWrapped = true
Banisher.TextXAlignment = Enum.TextXAlignment.Left
Banisher.MouseButton1Down:Connect(function()
wait(0.2)
Player = game:GetService("Players").LocalPlayer
PlayerGui = Player.PlayerGui
Cam = workspace.CurrentCamera
Backpack = Player.Backpack
Character = Player.Character
Humanoid = Character.Humanoid
Mouse = Player:GetMouse()
RootPart = Character.HumanoidRootPart
Torso = Character.Torso
Head = Character.Head
RightArm = Character["Right Arm"]
LeftArm = Character["Left Arm"]
RightLeg = Character["Right Leg"]
LeftLeg = Character["Left Leg"]
RootJoint = RootPart.RootJoint
Neck = Torso.Neck
RightShoulder = Torso["Right Shoulder"]
LeftShoulder = Torso["Left Shoulder"]
RightHip = Torso["Right Hip"]
LeftHip = Torso["Left Hip"]
local LastBolt
local LightningBolts = {}
local GunPoint
IT = Instance.new
CF = CFrame.new
VT = Vector3.new
RAD = math.rad
C3 = Color3.new
UD2 = UDim2.new
BRICKC = BrickColor.new
ANGLES = CFrame.Angles
EULER = CFrame.fromEulerAnglesXYZ
COS = math.cos
ACOS = math.acos
SIN = math.sin
ASIN = math.asin
ABS = math.abs
MRANDOM = math.random
FLOOR = math.floor
function CreateMesh(MESH, PARENT, MESHTYPE, MESHID, TEXTUREID, SCALE, OFFSET)
	local NEWMESH = IT(MESH)
	if MESH == "SpecialMesh" then
		NEWMESH.MeshType = MESHTYPE
		if MESHID ~= "nil" and MESHID ~= "" then
			NEWMESH.MeshId = "http://www.roblox.com/asset/?id=" .. MESHID
		end
		if TEXTUREID ~= "nil" and TEXTUREID ~= "" then
			NEWMESH.TextureId = "http://www.roblox.com/asset/?id=" .. TEXTUREID
		end
	end
	NEWMESH.Offset = OFFSET or VT(0, 0, 0)
	NEWMESH.Scale = SCALE
	NEWMESH.Parent = PARENT
	return NEWMESH
end
function CreatePart(FORMFACTOR, PARENT, MATERIAL, REFLECTANCE, TRANSPARENCY, BRICKCOLOR, NAME, SIZE, ANCHOR)
	local NEWPART = IT("Part")
	NEWPART.formFactor = FORMFACTOR
	NEWPART.Reflectance = REFLECTANCE
	NEWPART.Transparency = TRANSPARENCY
	NEWPART.CanCollide = false
	NEWPART.Locked = true
	NEWPART.Anchored = true
	if ANCHOR == false then
		NEWPART.Anchored = false
	end
	NEWPART.BrickColor = BRICKC(tostring(BRICKCOLOR))
	NEWPART.Name = NAME
	NEWPART.Size = SIZE
	NEWPART.Position = Torso.Position
	NEWPART.Material = MATERIAL
	NEWPART:BreakJoints()
	NEWPART.Parent = PARENT
	return NEWPART
end
Player_Size = 1
Animation_Speed = 3
Frame_Speed = 0.016666666666666666
local Speed = 16
local Effects2 = {}
local weldBetween = function(a, b)
	local weldd = Instance.new("ManualWeld")
	weldd.Part0 = a
	weldd.Part1 = b
	weldd.C0 = CFrame.new()
	weldd.C1 = b.CFrame:inverse() * a.CFrame
	weldd.Parent = a
	return weldd
end
function createaccessory(attachmentpart, mesh, texture, scale, offset, color)
	local acs = Instance.new("Part")
	acs.CanCollide = false
	acs.Anchored = false
	acs.Size = Vector3.new(0, 0, 0)
	acs.CFrame = attachmentpart.CFrame
	acs.Parent = Character
	acs.BrickColor = color
	local meshs = Instance.new("SpecialMesh")
	meshs.MeshId = mesh
	meshs.TextureId = texture
	meshs.Parent = acs
	meshs.Scale = scale
	meshs.Offset = offset
	weldBetween(attachmentpart, acs)
end
function createbodypart(TYPE, COLOR, PART, OFFSET, SIZE)
	if TYPE == "Gem" then
		local acs = CreatePart(3, Character, "Plastic", 0, 0, COLOR, "Part", VT(0, 0, 0))
		acs.Anchored = false
		acs.CanCollide = false
		acs.CFrame = PART.CFrame
		local acs2 = CreateMesh("SpecialMesh", acs, "FileMesh", "9756362", "", SIZE, OFFSET)
		weldBetween(PART, acs)
	elseif TYPE == "Skull" then
		local acs = CreatePart(3, Character, "Plastic", 0, 0, COLOR, "Part", VT(0, 0, 0))
		acs.Anchored = false
		acs.CanCollide = false
		acs.CFrame = PART.CFrame
		local acs2 = CreateMesh("SpecialMesh", acs, "FileMesh", "4770583", "", SIZE, OFFSET)
		weldBetween(PART, acs)
	elseif TYPE == "Eye" then
		local acs = CreatePart(3, Character, "Neon", 0, 0, COLOR, "Part", VT(0, 0, 0))
		acs.Anchored = false
		acs.CanCollide = false
		acs.CFrame = PART.CFrame
		local acs2 = CreateMesh("SpecialMesh", acs, "Sphere", "", "", SIZE, OFFSET)
		weldBetween(PART, acs)
	end
end
local ROOTC0 = CF(0, 0, 0) * ANGLES(RAD(-90), RAD(0), RAD(180))
local NECKC0 = CF(0, 1, 0) * ANGLES(RAD(-90), RAD(0), RAD(180))
local RIGHTSHOULDERC0 = CF(-0.5, 0, 0) * ANGLES(RAD(0), RAD(90), RAD(0))
local LEFTSHOULDERC0 = CF(0.5, 0, 0) * ANGLES(RAD(0), RAD(-90), RAD(0))
local CHANGEDEFENSE = 0
local CHANGEDAMAGE = 0
local CHANGEMOVEMENT = 0
local ANIM = "Idle"
local ATTACK = false
local EQUIPPED = false
local HOLD = false
local COMBO = 1
local Rooted = false
local SINE = 0
local KEYHOLD = false
local CHANGE = 2 / Animation_Speed
local WALKINGANIM = false
local WALK = 0
local VALUE1 = false
local VALUE2 = false
local ROBLOXIDLEANIMATION = IT("Animation")
ROBLOXIDLEANIMATION.Name = "Roblox Idle Animation"
ROBLOXIDLEANIMATION.AnimationId = "http://www.roblox.com/asset/?id=180435571"
local WEAPONGUI = IT("ScreenGui", PlayerGui)
WEAPONGUI.Name = "Weapon GUI"
local Weapon = IT("Model")
Weapon.Name = "Adds"
local Delete = IT("Model", Character)
Delete.Name = "Those who must be banished."
local Effects = IT("Folder", Weapon)
Effects.Name = "Effects"
local ANIMATOR = Humanoid.Animator
local ANIMATE = Character.Animate
local HITPLAYERSOUNDS = {
	"263032172",
	"263032182",
	"263032200",
	"263032221",
	"263032252",
	"263033191"
}
local HITARMORSOUNDS = {
	"199149321",
	"199149338",
	"199149367",
	"199149409",
	"199149452"
}
local HITWEAPONSOUNDS = {
	"199148971",
	"199149025",
	"199149072",
	"199149109",
	"199149119"
}
local HITBLOCKSOUNDS = {"199148933", "199148947"}
local UNANCHOR = true
local SKILLTEXTCOLOR = C3(0, 1, 1)
ArtificialHB = Instance.new("BindableEvent", script)
ArtificialHB.Name = "ArtificialHB"
script:WaitForChild("ArtificialHB")
frame = Frame_Speed
tf = 0
allowframeloss = false
tossremainder = false
lastframe = tick()
script.ArtificialHB:Fire()
game:GetService("RunService").Heartbeat:connect(function(s, p)
	tf = tf + s
	if tf >= frame then
		if allowframeloss then
			script.ArtificialHB:Fire()
			lastframe = tick()
		else
			for i = 1, math.floor(tf / frame) do
				script.ArtificialHB:Fire()
			end
			lastframe = tick()
		end
		if tossremainder then
			tf = 0
		else
			tf = tf - frame * math.floor(tf / frame)
		end
	end
end)
function Raycast(POSITION, DIRECTION, RANGE, IGNOREDECENDANTS)
	return workspace:FindPartOnRay(Ray.new(POSITION, DIRECTION.unit * RANGE), IGNOREDECENDANTS)
end
function PositiveAngle(NUMBER)
	if NUMBER >= 0 then
		NUMBER = 0
	end
	return NUMBER
end
function NegativeAngle(NUMBER)
	if NUMBER <= 0 then
		NUMBER = 0
	end
	return NUMBER
end
function Swait(NUMBER)
	if NUMBER == 0 or NUMBER == nil then
		ArtificialHB.Event:wait()
	else
		for i = 1, NUMBER do
			ArtificialHB.Event:wait()
		end
	end
end
function QuaternionFromCFrame(cf)
	local mx, my, mz, m00, m01, m02, m10, m11, m12, m20, m21, m22 = cf:components()
	local trace = m00 + m11 + m22
	if trace > 0 then
		local s = math.sqrt(1 + trace)
		local recip = 0.5 / s
		return (m21 - m12) * recip, (m02 - m20) * recip, (m10 - m01) * recip, s * 0.5
	else
		local i = 0
		if m00 < m11 then
			i = 1
		end
		if m22 > (i == 0 and m00 or m11) then
			i = 2
		end
		if i == 0 then
			local s = math.sqrt(m00 - m11 - m22 + 1)
			local recip = 0.5 / s
			return 0.5 * s, (m10 + m01) * recip, (m20 + m02) * recip, (m21 - m12) * recip
		elseif i == 1 then
			local s = math.sqrt(m11 - m22 - m00 + 1)
			local recip = 0.5 / s
			return (m01 + m10) * recip, 0.5 * s, (m21 + m12) * recip, (m02 - m20) * recip
		elseif i == 2 then
			local s = math.sqrt(m22 - m00 - m11 + 1)
			local recip = 0.5 / s
			return (m02 + m20) * recip, (m12 + m21) * recip, 0.5 * s, (m10 - m01) * recip
		end
	end
end
function QuaternionToCFrame(px, py, pz, x, y, z, w)
	local xs, ys, zs = x + x, y + y, z + z
	local wx, wy, wz = w * xs, w * ys, w * zs
	local xx = x * xs
	local xy = x * ys
	local xz = x * zs
	local yy = y * ys
	local yz = y * zs
	local zz = z * zs
	return CFrame.new(px, py, pz, 1 - (yy + zz), xy - wz, xz + wy, xy + wz, 1 - (xx + zz), yz - wx, xz - wy, yz + wx, 1 - (xx + yy))
end
function QuaternionSlerp(a, b, t)
	local cosTheta = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] + a[4] * b[4]
	local startInterp, finishInterp
	if cosTheta >= 1.0E-4 then
		if 1 - cosTheta > 1.0E-4 then
			local theta = ACOS(cosTheta)
			local invSinTheta = 1 / SIN(theta)
			startInterp = SIN((1 - t) * theta) * invSinTheta
			finishInterp = SIN(t * theta) * invSinTheta
		else
			startInterp = 1 - t
			finishInterp = t
		end
	elseif 1 + cosTheta > 1.0E-4 then
		local theta = ACOS(-cosTheta)
		local invSinTheta = 1 / SIN(theta)
		startInterp = SIN((t - 1) * theta) * invSinTheta
		finishInterp = SIN(t * theta) * invSinTheta
	else
		startInterp = t - 1
		finishInterp = t
	end
	return a[1] * startInterp + b[1] * finishInterp, a[2] * startInterp + b[2] * finishInterp, a[3] * startInterp + b[3] * finishInterp, a[4] * startInterp + b[4] * finishInterp
end
function Clerp(a, b, t)
	local qa = {
		QuaternionFromCFrame(a)
	}
	local qb = {
		QuaternionFromCFrame(b)
	}
	local ax, ay, az = a.x, a.y, a.z
	local bx, by, bz = b.x, b.y, b.z
	local _t = 1 - t
	return QuaternionToCFrame(_t * ax + t * bx, _t * ay + t * by, _t * az + t * bz, QuaternionSlerp(qa, qb, t))
end
function CreateFrame(PARENT, TRANSPARENCY, BORDERSIZEPIXEL, POSITION, SIZE, COLOR, BORDERCOLOR, NAME)
	local frame = IT("Frame")
	frame.BackgroundTransparency = TRANSPARENCY
	frame.BorderSizePixel = BORDERSIZEPIXEL
	frame.Position = POSITION
	frame.Size = SIZE
	frame.BackgroundColor3 = COLOR
	frame.BorderColor3 = BORDERCOLOR
	frame.Name = NAME
	frame.Parent = PARENT
	return frame
end
function CreateLabel(PARENT, TEXT, TEXTCOLOR, TEXTFONTSIZE, TEXTFONT, TRANSPARENCY, BORDERSIZEPIXEL, STROKETRANSPARENCY, NAME)
	local label = IT("TextLabel")
	label.BackgroundTransparency = 1
	label.Size = UD2(1, 0, 1, 0)
	label.Position = UD2(0, 0, 0, 0)
	label.TextColor3 = TEXTCOLOR
	label.TextStrokeTransparency = STROKETRANSPARENCY
	label.TextTransparency = TRANSPARENCY
	label.FontSize = TEXTFONTSIZE
	label.Font = TEXTFONT
	label.BorderSizePixel = BORDERSIZEPIXEL
	label.TextScaled = false
	label.Text = TEXT
	label.Name = NAME
	label.Parent = PARENT
	return label
end
function NoOutlines(PART)
	PART.TopSurface, PART.BottomSurface, PART.LeftSurface, PART.RightSurface, PART.FrontSurface, PART.BackSurface = 10, 10, 10, 10, 10, 10
end
function CreateWeldOrSnapOrMotor(TYPE, PARENT, PART0, PART1, C0, C1)
	local NEWWELD = IT(TYPE)
	NEWWELD.Part0 = PART0
	NEWWELD.Part1 = PART1
	NEWWELD.C0 = C0
	NEWWELD.C1 = C1
	NEWWELD.Parent = PARENT
	return NEWWELD
end
local SOUND = IT("Sound", nil)
function CreateSound(ID, PARENT, VOLUME, PITCH)
	local NEWSOUND
	coroutine.resume(coroutine.create(function()
		NEWSOUND = SOUND:Clone()
		NEWSOUND.Parent = PARENT
		NEWSOUND.Volume = VOLUME
		NEWSOUND.Pitch = PITCH
		NEWSOUND.SoundId = "http://www.roblox.com/asset/?id=" .. ID
		NEWSOUND:play()
		repeat
			Swait()
		until NEWSOUND.Playing == false
		NEWSOUND:remove()
	end))
	return NEWSOUND
end
function CFrameFromTopBack(at, top, back)
	local right = top:Cross(back)
	return CF(at.x, at.y, at.z, right.x, top.x, back.x, right.y, top.y, back.y, right.z, top.z, back.z)
end
function CreateWave(SIZE, WAIT, CFRAME, DOESROT, ROT, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=20329976"
	mesh.Scale = SIZE
	mesh.Offset = VT(0, 0, -SIZE.X / 8)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			mesh.Offset = VT(0, 0, -(mesh.Scale.X / 8))
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function CreateCrown(SIZE, WAIT, CFRAME, DOESROT, ROT, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=1078075"
	mesh.Scale = SIZE
	mesh.Offset = VT(0, 0, -SIZE.X / 8)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			mesh.Offset = VT(0, 0, -(mesh.Scale.X / 8))
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function CreateIceCrown(SIZE, WAIT, CFRAME, DOESROT, ROT, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=1323306"
	mesh.Scale = SIZE
	mesh.Offset = VT(0, 0, -SIZE.X / 8)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			mesh.Offset = VT(0, 0, -(mesh.Scale.X / 8))
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function CreateSpikeball(SIZE, WAIT, CFRAME, DOESROT, ROT, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=9982590"
	mesh.Scale = SIZE
	mesh.Offset = VT(0, 0, -SIZE.X / 8)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			mesh.Offset = VT(0, 0, -(mesh.Scale.X / 8))
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function CreateSwirl(SIZE, WAIT, CFRAME, DOESROT, ROT, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=1051557"
	mesh.Scale = SIZE
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			mesh.Offset = VT(0, 0, -(mesh.Scale.X / 8))
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function CreateTornado(SIZE, DOESROT, ROT, WAIT, CFRAME, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=102638417"
	mesh.Scale = SIZE
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function CreateRing(SIZE, DOESROT, ROT, WAIT, CFRAME, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0.5, BRICKC(COLOR), "Effect", VT(0, 0, 0))
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "FileMesh"
	mesh.MeshId = "http://www.roblox.com/asset/?id=3270017"
	mesh.Scale = SIZE
	mesh.Offset = VT(0, 0, 0)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			if DOESROT == true then
				wave.CFrame = wave.CFrame * CFrame.fromEulerAnglesXYZ(0, ROT, 0)
			end
			wave.Transparency = wave.Transparency + 0.5 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function MagicSphere(SIZE, WAIT, CFRAME, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0, BRICKC(COLOR), "Effect", VT(1, 1, 1), true)
	local mesh = IT("SpecialMesh", wave)
	mesh.MeshType = "Sphere"
	mesh.Scale = SIZE
	mesh.Offset = VT(0, 0, 0)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			wave.Transparency = wave.Transparency + 1 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function MagicBlock(SIZE, WAIT, CFRAME, COLOR, GROW)
	local wave = CreatePart(3, Effects, "Neon", 0, 0, BRICKC(COLOR), "Effect", VT(SIZE, SIZE, SIZE), true)
	local mesh = IT("BlockMesh", wave)
	wave.CFrame = CFRAME
	coroutine.resume(coroutine.create(function(PART)
		for i = 1, WAIT do
			Swait()
			mesh.Scale = mesh.Scale + GROW
			wave.CFrame = CFRAME * ANGLES(RAD(math.random(-360, 360)), RAD(math.random(-360, 360)), RAD(math.random(-360, 360)))
			wave.Transparency = wave.Transparency + 1 / WAIT
			if wave.Transparency > 0.99 then
				wave:remove()
			end
		end
	end))
end
function MakeForm(PART, TYPE)
	if TYPE == "Cyl" then
		local MSH = IT("CylinderMesh", PART)
	elseif TYPE == "Ball" then
		local MSH = IT("SpecialMesh", PART)
		MSH.MeshType = "Sphere"
	elseif TYPE == "Wedge" then
		local MSH = IT("SpecialMesh", PART)
		MSH.MeshType = "Wedge"
	end
end
function CheckTableForString(Table, String)
	for i, v in pairs(Table) do
		if string.find(string.lower(String), string.lower(v)) then
			return true
		end
	end
	return false
end
function CheckIntangible(Hit)
	local ProjectileNames = {
		"Water",
		"Arrow",
		"Projectile",
		"Effect",
		"Rail",
		"Lightning",
		"Bullet"
	}
	if Hit and Hit.Parent and (not Hit.CanCollide or CheckTableForString(ProjectileNames, Hit.Name)) and not Hit.Parent:FindFirstChild("Humanoid") then
		return true
	end
	return false
end
Debris = game:GetService("Debris")
BaseLightning = IT("Part")
BaseLightning.Anchored = true
BaseLightning.CanCollide = false
BaseLightning.Material = "Neon"
function CastZapRay(StartPos, Vec, Length, Ignore, DelayIfHit)
	local Ignore = type(Ignore) == "table" and Ignore or {Ignore}
	local RayHit, RayPos, RayNormal = game:GetService("Workspace"):FindPartOnRayWithIgnoreList(Ray.new(StartPos, Vec * Length), Ignore)
	if RayHit and CheckIntangible(RayHit) then
		if DelayIfHit then
			wait()
		end
		RayHit, RayPos, RayNormal = CastZapRay(RayPos + Vec * 0.01, Vec, Length - (StartPos - RayPos).magnitude, Ignore, DelayIfHit)
	end
	return RayHit, RayPos, RayNormal
end
function Zap(Table)
	local StartPos, TargetPos, Character, Color = Table.StartPosition, Table.TargetPosition, Table.Character, Table.Color
	local Duration = Table.Duration or 2
	local FadeRate = Table.FadeRate or 0.05
	local Offset = Table.Offset or 2
	local Individualize = Table.Individualize or false
	local MaxRange = Table.MaxRange or 200
	local SegmentLength = Table.SegmentLength or 5
	local TimeToFade = Table.TimeToFade or 0.5
	local Ignore = Table.Ignore or {}
	local SIZE = Table.Size or 0.3
	if not (StartPos and TargetPos) or not Character then
		return
	end
	local LightningModel = IT("Folder", Effects)
	LightningModel.Name = "ZAPP"
	for i, v in pairs({Character, LightningModel}) do
		table.insert(Ignore, v)
	end
	local LastPos = StartPos
	local Direction = CFrame.new(StartPos, TargetPos).lookVector
	local RayHit, RayPos, RayNormal = CastZapRay(StartPos, Direction, MaxRange, Ignore, false)
	local RayLength = (StartPos - RayPos).Magnitude
	local Struck = false
	local TotalSegments = math.ceil(RayLength / SegmentLength)
	Direction = CFrame.new(StartPos, RayPos).lookVector
	local LightningBolt = IT("Model", Effects)
	LightningBolt.Name = "Lightning"
	if not Individualize then
		table.insert(LightningBolts, LightningBolt)
	end
	LastBolt = LightningBolt
	Debris:AddItem(LightningBolt, Duration)
	LightningBolt.Parent = LightningModel
	for i = 1, TotalSegments do
		if not Struck then
			local Entropy = Vector3.new(math.random() * Offset * 2.5 - Offset, math.random() * Offset * 2.5 - Offset, math.random() * Offset * 2.5 - Offset)
			local NewPos = StartPos + Direction * (RayLength * (i / TotalSegments)) + Entropy
			local SegmentVec = NewPos - LastPos
			local RayHit, RayPos, RayNormal = CastZapRay(LastPos, SegmentVec.Unit, SegmentVec.Magnitude, {Character, LightningModel}, false)
			local RayVec = LastPos - RayPos
			local LightningPart = BaseLightning:Clone()
			LightningPart.BrickColor = BrickColor.new(Color)
			LightningPart.Size = Vector3.new(SIZE, SIZE, RayVec.Magnitude)
			LightningPart.CFrame = CFrame.new(LastPos, RayPos) * CFrame.new(0, 0, -(RayVec.Magnitude / 2))
			table.insert(Effects2, {
				LightningPart,
				"Disappear",
				0.025,
				1,
				1,
				1,
				2
			})
			local CylinderMesh = IT("CylinderMesh", LightningPart)
			local OrigCF = LightningPart.CFrame
			LightningPart.Size = Vector3.new(LightningPart.Size.X, LightningPart.Size.Z, LightningPart.Size.Y)
			LightningPart.CFrame = OrigCF * CFrame.Angles(math.pi / 2, 0, 0)
			LightningPart.Parent = LightningBolt
			LastPos = NewPos
		end
	end
	return {
		RayHit = RayHit,
		RayPos = RayPos,
		RayNormal = RayNormal,
		LightningModel = LightningModel
	}
end
function turnto(position)
	RootPart.CFrame = CFrame.new(RootPart.CFrame.p, VT(position.X, RootPart.Position.Y, position.Z)) * CFrame.new(0, 0, 0)
end
function chatfunc(text, waitt)
	local chat = coroutine.wrap(function()
		if Character:FindFirstChild("TalkingBillBoard") ~= nil then
			Character:FindFirstChild("TalkingBillBoard").Parent = nil
		end
		local naeeym2 = Instance.new("BillboardGui", Character)
		naeeym2.Size = UDim2.new(0, 100, 0, 40)
		naeeym2.StudsOffset = Vector3.new(0, 2, 0)
		naeeym2.Adornee = Character.Head
		naeeym2.Name = "TalkingBillBoard"
		naeeym2.AlwaysOnTop = true
		local tecks2 = Instance.new("TextLabel", naeeym2)
		tecks2.BackgroundTransparency = 1
		tecks2.BorderSizePixel = 0
		tecks2.Text = ""
		tecks2.Font = "Antique"
		tecks2.TextSize = 30
		tecks2.TextStrokeTransparency = 1
		tecks2.TextColor3 = SKILLTEXTCOLOR
		tecks2.TextStrokeColor3 = Color3.new(0, 0, 0)
		tecks2.Size = UDim2.new(1, 0, 0.5, 0)
		for i = 1, string.len(text) do
			if naeeym2.Parent ~= nil then
				CreateSound("928210219", Effects, 3, MRANDOM(8, 8) / 10)
			end
			tecks2.Text = string.sub(text, 1, i)
			Swait(3)
		end
		wait(waitt / 10)
		coroutine.resume(coroutine.create(function()
			for i = 1, 10 do
				tecks2.TextTransparency = tecks2.TextTransparency + 0.1
				Swait()
			end
			naeeym2:Destroy()
		end))
	end)
	chat()
end
for _, c in pairs(Weapon:GetChildren()) do
	if c.ClassName == "Part" then
		c.CustomPhysicalProperties = PhysicalProperties.new(0, 0, 0, 0, 0)
	end
end
Weapon.Parent = Character
Humanoid.Died:connect(function()
	ATTACK = true
end)
local SKILL1FRAME = CreateFrame(WEAPONGUI, 1, 2, UD2(0.23, 0, 0.8, 0), UD2(0.26, 0, 0.07, 0), C3(0, 0, 0), C3(0, 0, 0), "Skill 1 Frame")
local SKILL2FRAME = CreateFrame(WEAPONGUI, 1, 2, UD2(0.5, 0, 0.8, 0), UD2(0.26, 0, 0.07, 0), C3(0, 0, 0), C3(0, 0, 0), "Skill 2 Frame")
local SKILL3FRAME = CreateFrame(WEAPONGUI, 1, 2, UD2(0.23, 0, 0.93, 0), UD2(0.26, 0, 0.07, 0), C3(0, 0, 0), C3(0, 0, 0), "Skill 3 Frame")
local SKILL4FRAME = CreateFrame(WEAPONGUI, 1, 2, UD2(0.5, 0, 0.93, 0), UD2(0.26, 0, 0.07, 0), C3(0, 0, 0), C3(0, 0, 0), "Skill 4 Frame")
local SKILL5FRAME = CreateFrame(WEAPONGUI, 1, 2, UD2(0.365, 0, 0.7, 0), UD2(0.26, 0, 0.07, 0), C3(0, 0, 0), C3(0, 0, 0), "Skill 5 Frame")
local SKILL1TEXT = CreateLabel(SKILL1FRAME, "[Z] Banisher bullet", SKILLTEXTCOLOR, 8, "Antique", 0, 2, 1, "Text 1")
local SKILL2TEXT = CreateLabel(SKILL2FRAME, "[B] Banishing rampage", SKILLTEXTCOLOR, 8, "Antique", 0, 2, 1, "Text 2")
local SKILL3TEXT = CreateLabel(SKILL3FRAME, "[C] Warp vector", SKILLTEXTCOLOR, 8, "Antique", 0, 2, 1, "Text 3")
local SKILL4TEXT = CreateLabel(SKILL4FRAME, "[V] Spectral banish", SKILLTEXTCOLOR, 8, "Antique", 0, 2, 1, "Text 4")
local SKILL5TEXT = CreateLabel(SKILL5FRAME, "[X] De-banish", SKILLTEXTCOLOR, 8, "Antique", 0, 2, 1, "Text 5")
function CastWarpOutlines(TARGET)
	coroutine.resume(coroutine.create(function()
		local T = TARGET:GetChildren()
		for i = 1, #T do
			local child = T[i]
			if child.ClassName == "Part" or child.ClassName == "MeshPart" then
				do
					local clone = child:Clone()
					clone.Parent = Effects
					clone.Anchored = true
					clone.CanCollide = false
					clone:ClearAllChildren()
					clone.CFrame = child.CFrame
					if clone.Name == "Head" then
						clone.Size = VT(clone.Size.Y, clone.Size.Y, clone.Size.Y)
					end
					if clone.ClassName == "MeshPart" then
						clone.TextureID = ""
					end
					clone.Color = C3(0, 1, 1)
					clone.Material = "Neon"
					coroutine.resume(coroutine.create(function()
						for i = 1, 100 do
							Swait()
							clone.Transparency = clone.Transparency + 0.01
							clone.Size = clone.Size + VT(0.001, 0.001, 0.001)
						end
						clone:remove()
					end))
				end
			end
		end
	end))
end
function killnearest(position, range, maxstrength)
	for i, v in ipairs(workspace:GetChildren()) do
		local body = v:GetChildren()
		for part = 1, #body do
			if (body[part].ClassName == "Part" or body[part].ClassName == "MeshPart") and v ~= Character and range > (body[part].Position - position).Magnitude and v.ClassName == "Model" then
				CastWarpOutlines(v)
				v:remove()
				if game.Players:FindFirstChild(v.Name) then
					local Value = IT("BoolValue", Delete)
					Value.Name = v.Name
				end
			end
		end
	end
end
function CastProperRay(StartPos, Vec, Length, Ignore)
	local Direction = CFrame.new(StartPos, Vec).lookVector
	local Ignore = type(Ignore) == "table" and Ignore or {Ignore}
	local RayHit, RayPos, RayNormal = game:GetService("Workspace"):FindPartOnRayWithIgnoreList(Ray.new(StartPos, Direction * Length), Ignore)
	return RayHit, RayPos, RayNormal
end
function Debree(POS, SWAIT)
	coroutine.resume(coroutine.create(function()
		local HOLDER = IT("Model", Effects)
		HOLDER.Name = "Debree"
		local HITFLOOR = Raycast(POS, CF(POS, POS + VT(0, -1, 0)).lookVector, 4 * Player_Size, Character)
		MagicSphere(VT(15, 1, 15), SWAIT, CF(POS), "Eggplant", VT(0, 0, 0))
		MagicSphere(VT(13, 1, 13), SWAIT, CF(POS), "Eggplant", VT(0, 0, 0))
		MagicSphere(VT(12, 1, 12), SWAIT, CF(POS), "Eggplant", VT(0, 0, 0))
		repeat
			Swait()
		until HITFLOOR ~= nil
		local O = 0
		for i = 1, 18 do
			do
				local Part = CreatePart(3, HOLDER, HITFLOOR.Material, 0, 0, HITFLOOR.BrickColor, "Debree", VT(3, 3, 3))
				Part.CFrame = CF(CF(POS) * CF(10 - i, 0, O).p) * ANGLES(RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)))
				O = O - 2.25 + i / 4
				coroutine.resume(coroutine.create(function()
					Swait(SWAIT)
					for i = 1, 60 do
						Swait()
						local RayHit, Way = CastProperRay(Part.Position, POS, 0.1, workspace)
						Part.CFrame = CF(Way) * ANGLES(RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)))
					end
					for i = 1, 50 do
						Swait()
						Part.Size = Part.Size * 0.9
					end
				end))
			end
		end
		local O = 0
		for i = 1, 18 do
			do
				local Part = CreatePart(3, HOLDER, HITFLOOR.Material, 0, 0, HITFLOOR.BrickColor, "Debree", VT(3, 3, 3))
				Part.CFrame = CF(CF(POS) * CF(10 - i, 0, O).p) * ANGLES(RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)))
				O = O + 2.25 - i / 4
				coroutine.resume(coroutine.create(function()
					Swait(SWAIT)
					for i = 1, 60 do
						Swait()
						local RayHit, Way = CastProperRay(Part.Position, POS, 0.1, workspace)
						Part.CFrame = CF(Way) * ANGLES(RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)))
					end
					for i = 1, 50 do
						Swait()
						Part.Size = Part.Size * 0.9
					end
				end))
			end
		end
		Swait(SWAIT + 110)
		HOLDER:remove()
	end))
end
function Intro()
	coroutine.resume(coroutine.create(function()
		ATTACK = true
		Rooted = true
		for i = 0, 3, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(12)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
		end
		CreateSound("300208779", Head, 10, 1)
		for i = 0, 1, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -1.5) * ANGLES(RAD(0), RAD(5), RAD(0)), 0.5 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(15), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 1, -0.3) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, 0.5, -0.75) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(5), RAD(0), RAD(0)), 0.5 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.4) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(5), RAD(0), RAD(90)), 0.5 / Animation_Speed)
		end
		local HITFLOOR = Raycast(RootPart.Position, CF(RootPart.Position, RootPart.Position + VT(0, -1, 0)).lookVector, 4 * Player_Size, Character)
		repeat
			Swait()
			HITFLOOR = Raycast(RootPart.Position, CF(RootPart.Position, RootPart.Position + VT(0, -1, 0)).lookVector, 4 * Player_Size, Character)
		until HITFLOOR ~= nil
		for i = 0, 0.5, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -1.5) * ANGLES(RAD(0), RAD(-5), RAD(0)), 0.5 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(15), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0, -0.3) * ANGLES(RAD(0), RAD(0), RAD(8)) * RIGHTSHOULDERC0, 1 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, 0.5, -0.75) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(0)), 0.5 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.4) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(90)), 0.5 / Animation_Speed)
		end
		CreateSound("289842971", RightArm, 10, 1)
		Debree(CF(RightArm.Position) * CF(0, -0.75, 0).p, 200)
		Swait(45)
		local Gun = CreatePart(3, Weapon, "SmoothPlastic", 0, 0, "Really black", "Gun", VT(0, 0, 0), false)
		local HandleMesh = CreateMesh("SpecialMesh", Gun, "FileMesh", "868997239", "153921018", VT(-0.005, 0.005, -0.005), VT(0, 0, 0))
		local Weld = CreateWeldOrSnapOrMotor("Weld", Gun, RightArm, Gun, CF(0, -1.7, -0.2) * ANGLES(RAD(0), RAD(90), RAD(-90)), CF(0, 0, 0))
		GunPoint = CreatePart(3, Weapon, "SmoothPlastic", 0, 1, "Really black", "Point blank", VT(0, 0, 0), false)
		local HandleWeld = CreateWeldOrSnapOrMotor("Weld", GunPoint, RightArm, GunPoint, CF(0, -3.1, -0.8) * ANGLES(RAD(0), RAD(0), RAD(135)), CF(0, 0, 0))
		local sick = Instance.new("Sound", Character)
		sick.SoundId = "rbxassetid://1504604335"
		sick.Looped = true
		sick.Pitch = 1
		sick.Volume = 2
		sick:Play()
		Swait(5)
		for i = 0, 1, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -1.5) * ANGLES(RAD(0), RAD(5), RAD(0)), 0.5 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(15), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 1.25, -0.3) * ANGLES(RAD(0), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, 0.5, -0.75) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(5), RAD(0), RAD(0)), 0.5 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.4) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(5), RAD(0), RAD(90)), 0.5 / Animation_Speed)
		end
		VALUE1 = true
		Swait(10)
		ATTACK = false
		Rooted = false
	end))
end
function BanishingBullet()
	ATTACK = true
	Rooted = false
	for i = 0, 0.4, 0.1 / Animation_Speed do
		Swait()
		turnto(Mouse.Hit.p)
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(90)), 0.5 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(-90)), 0.5 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(90), RAD(0), RAD(90)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
	end
	repeat
		for i = 0, 0.2, 0.1 / Animation_Speed do
			Swait()
			turnto(Mouse.Hit.p)
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(90)), 0.5 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(-90)), 0.5 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(90), RAD(0), RAD(90)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		end
		CreateSound("131205975", GunPoint, 5, MRANDOM(9, 11) / 10)
		MagicSphere(VT(0.1, 0.1, 0.1), 45, GunPoint.CFrame, "Eggplant", VT(0.1, 0.1, 0.1))
		MagicSphere(VT(0.1, 0.1, 0.1), 45, GunPoint.CFrame, "Eggplant", VT(0.05, 0.05, 0.05))
		local RayHit, Way = CastProperRay(GunPoint.Position, Mouse.Hit.p, 1500, Character)
		local distance = (GunPoint.Position - Way).magnitude
		for i = 1, 5 do
			local laser = Instance.new("Part", Effects)
			laser.Transparency = 0
			laser.CanCollide = false
			laser.Anchored = true
			laser.Color = C3(0, 1, 1)
			laser.Material = "Neon"
			laser.formFactor = Enum.FormFactor.Custom
			laser.Size = Vector3.new(0.15, 0.15, distance)
			laser.CFrame = CFrame.new(GunPoint.Position, Way) * CFrame.new(0, 0, -distance / 2)
			MagicSphere(VT(0.1, 0.1, 0.1), 45, CF(Way), "Eggplant", VT(0.05, 0.05, 0.05))
			for i = 1, 5 do
				MagicSphere(VT(0.2, 0.2, 1), 65, CF(CF(Way) * CF(MRANDOM(-1, 1), MRANDOM(-1, 1), MRANDOM(-1, 1)).p, Way), "Eggplant", VT(0.001, 0.001, 0), 0.5)
			end
			table.insert(Effects2, {
				laser,
				"Disappear",
				0.1,
				1,
				1,
				1,
				2
			})
			if RayHit ~= nil then
				local v = RayHit.Parent
				if v ~= nil and v.ClassName == "Model" then
					CastWarpOutlines(v)
					v.Parent = nil
					if game.Players:FindFirstChild(v.Name) then
						local Value = IT("BoolValue", Delete)
						Value.Name = v.Name
					end
				end
			end
		end
		for i = 0, 0.3, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(90)), 0.5 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(-90)), 0.25 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(90), RAD(15), RAD(90)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		end
	until KEYHOLD == false
	ATTACK = false
	Rooted = false
end
function WarpVector()
	ATTACK = true
	Rooted = true
	for i = 0, 1, 0.1 / Animation_Speed do
		Swait()
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(45), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
	end
	Debree(CF(RootPart.Position) * CF(0, -2.8, 0).p, 75)
	UNANCHOR = false
	RootPart.Anchored = true
	for i = 0, 2, 0.1 / Animation_Speed do
		Swait()
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -10 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(45), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
	end
	local POS = RootPart.Position
	RootPart.CFrame = CF(CF(Mouse.Hit.p) * CF(0, 2.8, 0).p, POS)
	Debree(CF(RootPart.Position) * CF(0, -2.5, 0).p, 150)
	for i = 0, 2, 0.1 / Animation_Speed do
		Swait()
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(45), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.5 / Animation_Speed)
	end
	ATTACK = false
	Rooted = false
end
function BanishingRampage()
	ATTACK = true
	Rooted = false
	chatfunc("Be gone...", 3)
	for i = 0, 2, 0.1 / Animation_Speed do
		Swait()
		turnto(Mouse.Hit.p)
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -1.5) * ANGLES(RAD(0), RAD(0), RAD(45)), 0.5 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(15), RAD(0), RAD(-45)), 0.15 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 1, -0.3) * ANGLES(RAD(25), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, 0.5, -0.75) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.4) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(90)), 0.5 / Animation_Speed)
	end
	local HITFLOOR = Raycast(RootPart.Position, CF(RootPart.Position, RootPart.Position + VT(0, -1, 0)).lookVector, 4 * Player_Size, Character)
	repeat
		Swait()
		HITFLOOR = Raycast(RootPart.Position, CF(RootPart.Position, RootPart.Position + VT(0, -1, 0)).lookVector, 4 * Player_Size, Character)
	until HITFLOOR ~= nil
	CreateSound("131205975", GunPoint, 10, MRANDOM(9, 11) / 10)
	local SOUND = CreateSound("415700134", Effects, 10, 1.6)
	CreateSound("138677306", Effects, 7, 1.2)
	coroutine.resume(coroutine.create(function()
		local CFRAME = RootPart.CFrame * CF(0, -1.2, -3)
		local SIZE = 1
		while true do
			Swait()
			for i = 1, 2 do
				MagicSphere(VT(SIZE / 5, SIZE / 5, SIZE * 2), 65, CF(CFRAME * CF(MRANDOM(-5, 5), MRANDOM(-5, 5), MRANDOM(-5, 5)).p, CFRAME.p), "Eggplant", VT(0.001, 0.001, 0), 0.5)
			end
			do
				local Part = CreatePart(3, Effects, HITFLOOR.Material, 0, 0, HITFLOOR.BrickColor, "Debree", VT(SIZE / 5, SIZE / 5, SIZE / 5))
				Part.CFrame = CFRAME * CF(SIZE / 1.5, -0.7, 0) * ANGLES(RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)))
				coroutine.resume(coroutine.create(function()
					Swait(200)
					Part.Anchored = false
				end))
				local Part = CreatePart(3, Effects, HITFLOOR.Material, 0, 0, HITFLOOR.BrickColor, "Debree", VT(SIZE / 5, SIZE / 5, SIZE / 5))
				Part.CFrame = CFRAME * CF(-SIZE / 1.5, -0.7, 0) * ANGLES(RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)), RAD(MRANDOM(-180, 180)))
				coroutine.resume(coroutine.create(function()
					Swait(200)
					Part.Anchored = false
				end))
				MagicSphere(VT(SIZE, SIZE, SIZE), 75, CFRAME, "Eggplant", VT(-SIZE / 75, -SIZE / 75, -SIZE / 75))
				killnearest(CFRAME.p, SIZE, 0)
				SIZE = SIZE + 2
				CFRAME = CFRAME * CF(0, 0, -2)
				if SOUND.Playing == false then
					break
				end
			end
		end
	end))
	MagicSphere(VT(0.1, 0.1, 0.1), 45, GunPoint.CFrame, "Eggplant", VT(0.1, 0.1, 0.1))
	MagicSphere(VT(0.1, 0.1, 0.1), 45, GunPoint.CFrame, "Eggplant", VT(0.05, 0.05, 0.05))
	for i = 0, 3, 0.1 / Animation_Speed do
		Swait()
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, -1.5) * ANGLES(RAD(0), RAD(0), RAD(45)), 0.5 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(10), RAD(0), RAD(-45)), 0.15 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 1, -0.3) * ANGLES(RAD(55), RAD(0), RAD(0)) * RIGHTSHOULDERC0, 0.5 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-12)) * LEFTSHOULDERC0, 0.5 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, 0.5, -0.75) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.5 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.4) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(90)), 0.5 / Animation_Speed)
	end
	ATTACK = false
	Rooted = false
end
function SpectralBanishing()
	ATTACK = true
	Rooted = false
	chatfunc("If you desire to be a ghost...", 20)
	for i = 0, 5, 0.1 / Animation_Speed do
		Swait()
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(45)), 0.25 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(-45 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(-45)), 0.25 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(180), RAD(0), RAD(0)) * ANGLES(RAD(0), RAD(45), RAD(0)) * RIGHTSHOULDERC0, 0.25 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.25 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
	end
	chatfunc("Then move on to the afterlife!", 6)
	CreateSound("131205975", GunPoint, 10, MRANDOM(9, 11) / 10)
	MagicSphere(VT(0.1, 0.1, 0.1), 45, GunPoint.CFrame, "Eggplant", VT(0.1, 0.1, 0.1))
	MagicSphere(VT(0.1, 0.1, 0.1), 45, GunPoint.CFrame, "Eggplant", VT(0.05, 0.05, 0.05))
	local RayHit, Way = CastProperRay(GunPoint.Position, CF(GunPoint.Position) * CF(0, 1500, 0).p, 1500, Character)
	local distance = (GunPoint.Position - Way).magnitude
	for i = 1, 5 do
		local laser = Instance.new("Part", Effects)
		laser.Transparency = 0
		laser.CanCollide = false
		laser.Anchored = true
		laser.Color = C3(0, 1, 1)
		laser.Material = "Neon"
		laser.formFactor = Enum.FormFactor.Custom
		laser.Size = Vector3.new(0.15, 0.15, distance)
		laser.CFrame = CFrame.new(GunPoint.Position, Way) * CFrame.new(0, 0, -distance / 2)
		table.insert(Effects2, {
			laser,
			"Disappear",
			0.1,
			1,
			1,
			1,
			2
		})
	end
	coroutine.resume(coroutine.create(function()
		Swait(15)
		local FILTER = IT("ColorCorrectionEffect", game.Lighting)
		for i = 1, 25 do
			Swait()
			FILTER.TintColor = C3(1, 1 - i / 50, 1 - i / 50)
		end
		local GAME = game.Players:GetChildren()
		for PLAYER = 1, #GAME do
			do
				local PLAY = GAME[PLAYER]
				if PLAY.Character ~= nil and PLAY.Character.Parent ~= workspace then
					PLAY.Character.Parent = nil
					coroutine.resume(coroutine.create(function()
						if PLAY.Character:FindFirstChild("HumanoidRootPart") then
							PLAY.Character.Parent = workspace
							local Value = IT("BoolValue", Delete)
							Value.Name = PLAY.Name
						end
					end))
				end
			end
		end
		for i = 1, 25 do
			Swait()
			FILTER.TintColor = C3(1, 0.4980392156862745 + i / 50, 0.4980392156862745 + i / 50)
		end
	end))
	for i = 0, 2, 0.1 / Animation_Speed do
		Swait()
		RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(45)), 0.25 / Animation_Speed)
		Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(-45 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(-45)), 0.25 / Animation_Speed)
		RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(195), RAD(0), RAD(0)) * ANGLES(RAD(0), RAD(45), RAD(0)) * RIGHTSHOULDERC0, 0.25 / Animation_Speed)
		LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.25 / Animation_Speed)
		RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
		LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
	end
	ATTACK = false
	Rooted = false
end
function Taunt()
	ATTACK = true
	Rooted = true
	CreateSound("649634100", Head, 10, 0.5)
	for i = 1, 3 do
		for i = 0, 0.7, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.25 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(15 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(15)), 0.5 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(145)) * ANGLES(RAD(0), RAD(90), RAD(0)) * RIGHTSHOULDERC0, 0.5)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-145)) * ANGLES(RAD(0), RAD(-90), RAD(0)) * LEFTSHOULDERC0, 0.5)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
		end
		for i = 0, 0.7, 0.1 / Animation_Speed do
			Swait()
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.25 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(15 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(-15)), 0.5 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(145)) * ANGLES(RAD(0), RAD(90), RAD(0)) * RIGHTSHOULDERC0, 0.5)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.5, 0) * ANGLES(RAD(0), RAD(0), RAD(-145)) * ANGLES(RAD(0), RAD(-90), RAD(0)) * LEFTSHOULDERC0, 0.5)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.25 / Animation_Speed)
		end
	end
	ATTACK = false
	Rooted = false
end
function MouseDown(Mouse)
	if ATTACK == false then
	end
end
function MouseUp(Mouse)
	HOLD = false
end
function KeyDown(Key)
	KEYHOLD = true
	if Key == "z" and ATTACK == false then
		BanishingBullet()
	end
	if Key == "b" and ATTACK == false then
		BanishingRampage()
	end
	if Key == "c" and ATTACK == false then
		WarpVector()
	end
	if Key == "v" and ATTACK == false then
		SpectralBanishing()
	end
	if Key == "x" and ATTACK == false then
		chatfunc("I will show you mercy.", 2)
		Delete:ClearAllChildren()
	end
	if Key == "t" and ATTACK == false then
		Taunt()
	end
end
function KeyUp(Key)
	KEYHOLD = false
end
Mouse.Button1Down:connect(function(NEWKEY)
	MouseDown(NEWKEY)
end)
Mouse.Button1Up:connect(function(NEWKEY)
	MouseUp(NEWKEY)
end)
Mouse.KeyDown:connect(function(NEWKEY)
	KeyDown(NEWKEY)
end)
Mouse.KeyUp:connect(function(NEWKEY)
	KeyUp(NEWKEY)
end)
function unanchor()
	if UNANCHOR == true then
		g = Character:GetChildren()
		for i = 1, #g do
			if g[i].ClassName == "Part" then
				g[i].Anchored = false
			end
		end
	end
end
Humanoid.Changed:connect(function(Jump)
	if Jump == "Jump" and Disable_Jump == true then
		Humanoid.Jump = false
	end
end)
local BOLT
local FF = IT("ForceField", Character)
FF.Visible = false
while true do
	Swait()
	if BOLT ~= nil then
		BOLT:remove()
	end
	ANIMATE.Parent = nil
	local IDLEANIMATION = Humanoid:LoadAnimation(ROBLOXIDLEANIMATION)
	IDLEANIMATION:Play()
	SINE = SINE + CHANGE
	local TORSOVELOCITY = (RootPart.Velocity * VT(1, 0, 1)).magnitude
	local TORSOVERTICALVELOCITY = RootPart.Velocity.y
	local LV = Torso.CFrame:pointToObjectSpace(Torso.Velocity - Torso.Position)
	local HITFLOOR = Raycast(RootPart.Position, CF(RootPart.Position, RootPart.Position + VT(0, -1, 0)).lookVector, 4 * Player_Size, Character)
	local WALKSPEEDVALUE = 6 / (Humanoid.WalkSpeed / 16)
	if ANIM == "Walk" and TORSOVELOCITY > 1 then
		RootJoint.C1 = Clerp(RootJoint.C1, ROOTC0 * CF(0, 0, -0.1 * COS(SINE / (WALKSPEEDVALUE / 2)) * Player_Size) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 * (Humanoid.WalkSpeed / 16) / Animation_Speed)
		Neck.C1 = Clerp(Neck.C1, CF(0 * Player_Size, -0.5 * Player_Size, 0 * Player_Size) * ANGLES(RAD(-90), RAD(0), RAD(180)) * ANGLES(RAD(2.5 * SIN(SINE / (WALKSPEEDVALUE / 2))), RAD(0), RAD(0)), 0.2 * (Humanoid.WalkSpeed / 16) / Animation_Speed)
		RightHip.C1 = Clerp(RightHip.C1, CF(0.5 * Player_Size, 0.875 * Player_Size - 0.125 * SIN(SINE / WALKSPEEDVALUE) * Player_Size, -0.125 * COS(SINE / WALKSPEEDVALUE) * Player_Size) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(60 * COS(SINE / WALKSPEEDVALUE))), 0.2 * (Humanoid.WalkSpeed / 16) / Animation_Speed)
		LeftHip.C1 = Clerp(LeftHip.C1, CF(-0.5 * Player_Size, 0.875 * Player_Size + 0.125 * SIN(SINE / WALKSPEEDVALUE) * Player_Size, 0.125 * COS(SINE / WALKSPEEDVALUE) * Player_Size) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(60 * COS(SINE / WALKSPEEDVALUE))), 0.2 * (Humanoid.WalkSpeed / 16) / Animation_Speed)
	elseif ANIM ~= "Walk" or TORSOVELOCITY < 1 then
		RootJoint.C1 = Clerp(RootJoint.C1, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 / Animation_Speed)
		Neck.C1 = Clerp(Neck.C1, CF(0 * Player_Size, -0.5 * Player_Size, 0 * Player_Size) * ANGLES(RAD(-90), RAD(0), RAD(180)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 / Animation_Speed)
		RightHip.C1 = Clerp(RightHip.C1, CF(0.5 * Player_Size, 1 * Player_Size, 0 * Player_Size) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 / Animation_Speed)
		LeftHip.C1 = Clerp(LeftHip.C1, CF(-0.5 * Player_Size, 1 * Player_Size, 0 * Player_Size) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 / Animation_Speed)
	end
	if TORSOVERTICALVELOCITY > 1 and HITFLOOR == nil then
		ANIM = "Jump"
		if ATTACK == false then
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0 * Player_Size, 0) * ANGLES(RAD(-20), RAD(0), RAD(0)), 0.2 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(25), RAD(0), RAD(25)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, -0.3) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(-20)), 0.2 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, -0.3) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-5), RAD(0), RAD(20)), 0.2 / Animation_Speed)
		end
	elseif TORSOVERTICALVELOCITY < -1 and HITFLOOR == nil then
		ANIM = "Fall"
		if ATTACK == false then
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.2 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(20), RAD(0), RAD(0)), 0.2 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(55), RAD(0), RAD(55)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(20)), 0.2 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(10)), 0.2 / Animation_Speed)
		end
	elseif TORSOVELOCITY < 1 and HITFLOOR ~= nil then
		ANIM = "Idle"
		if ATTACK == false then
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0, 0, 0) * ANGLES(RAD(0 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(45), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1 - 0.05 * COS(SINE / 12), -0.01) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(-8), RAD(0), RAD(0)), 0.15 / Animation_Speed)
		end
	elseif TORSOVELOCITY > 1 and HITFLOOR ~= nil then
		ANIM = "Walk"
		WALK = WALK + 1 / Animation_Speed
		if WALK >= 15 - 5 * (Humanoid.WalkSpeed / 16 / Player_Size) then
			WALK = 0
			if WALKINGANIM == true then
				WALKINGANIM = false
			elseif WALKINGANIM == false then
				WALKINGANIM = true
			end
		end
		if ATTACK == false then
			RootJoint.C0 = Clerp(RootJoint.C0, ROOTC0 * CF(0, 0, 0 + 0.05 * COS(SINE / 12)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			Neck.C0 = Clerp(Neck.C0, NECKC0 * CF(0 * Player_Size, 0 * Player_Size, 0) * ANGLES(RAD(0 - 2.5 * SIN(SINE / 12)), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			RightShoulder.C0 = Clerp(RightShoulder.C0, CF(1.5, 0.5, 0) * ANGLES(RAD(45), RAD(0), RAD(45)) * RIGHTSHOULDERC0, 0.15 / Animation_Speed)
			LeftShoulder.C0 = Clerp(LeftShoulder.C0, CF(-1.5, 0.6, 0) * ANGLES(RAD(-45), RAD(0), RAD(45)) * LEFTSHOULDERC0, 0.15 / Animation_Speed)
			RightHip.C0 = Clerp(RightHip.C0, CF(1, -1, 0) * ANGLES(RAD(0), RAD(90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
			LeftHip.C0 = Clerp(LeftHip.C0, CF(-1, -1, 0) * ANGLES(RAD(0), RAD(-90), RAD(0)) * ANGLES(RAD(0), RAD(0), RAD(0)), 0.15 / Animation_Speed)
		end
	end
	if #Effects2 > 0 then
		for e = 1, #Effects2 do
			if Effects2[e] ~= nil then
				local Thing = Effects2[e]
				if Thing ~= nil then
					local Part = Thing[1]
					local Mode = Thing[2]
					local Delay = Thing[3]
					local IncX = Thing[4]
					local IncY = Thing[5]
					local IncZ = Thing[6]
					local Part2 = Thing[8]
					if Thing[1].Transparency <= 1 then
						if Thing[2] == "Block1" then
							Thing[1].CFrame = Thing[1].CFrame
							Mesh = Thing[1].Mesh
							Mesh.Scale = Mesh.Scale + VT(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Cylinder" then
							Mesh = Thing[1].Mesh
							Mesh.Scale = Mesh.Scale + VT(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Blood" then
							Mesh = Thing[7]
							Thing[1].CFrame = Thing[1].CFrame * CF(0, 0.5, 0)
							Mesh.Scale = Mesh.Scale + VT(Thing[4], Thing[5], Thing[6])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Elec" then
							Mesh = Thing[1].Mesh
							Mesh.Scale = Mesh.Scale + VT(Thing[7], Thing[8], Thing[9])
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						elseif Thing[2] == "Disappear" then
							Thing[1].Transparency = Thing[1].Transparency + Thing[3]
						end
					else
						Part.Parent = nil
						table.remove(Effects2, e)
					end
				end
			end
		end
	end
	unanchor()
	Humanoid.MaxHealth = "inf"
	Humanoid.Health = "inf"
	if Rooted == false then
		Disable_Jump = false
		Humanoid.WalkSpeed = Speed
	elseif Rooted == true then
		Disable_Jump = true
		Humanoid.WalkSpeed = 0
	end
	if VALUE1 == true then
		local RayData = Zap({
			SegmentLength = 0.6,
			Offset = 0.3,
			Size = 0.05,
			MaxRange = 1.5,
			StartPosition = GunPoint.Position,
			TargetPosition = RightArm.Position,
			Character = workspace,
			Color = "Eggplant",
			Individual = true
		})
		BOLT = RayData.LightningModel
		MagicSphere(VT(0.5, 0.5, 0.5), 15, GunPoint.CFrame, "Eggplant", VT(-0.03333333333333333, -0.03333333333333333, -0.03333333333333333))
		SKILL1TEXT.TextTransparency = 0
		SKILL2TEXT.TextTransparency = 0
		SKILL3TEXT.TextTransparency = 0
		SKILL4TEXT.TextTransparency = 0
		SKILL5TEXT.TextTransparency = 0
	elseif VALUE1 == false then
		if ATTACK == false then
			Intro()
		end
		SKILL1TEXT.TextTransparency = 1
		SKILL2TEXT.TextTransparency = 1
		SKILL3TEXT.TextTransparency = 1
		SKILL4TEXT.TextTransparency = 1
		SKILL5TEXT.TextTransparency = 1
	end
	local MATHS = {"0", "1"}
	Humanoid.Name = MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)] .. MATHS[MRANDOM(1, #MATHS)]
	Humanoid.PlatformStand = false
	local GAME = game.Players:GetChildren()
	for PLAYER = 1, #GAME do
		local PLAY = GAME[PLAYER]
		if PLAY.Character ~= nil and Delete:FindFirstChild(PLAY.Name) then
			PLAY.Character:remove()
		end
	end
end	
end)

UICorner_7.Parent = Banisher

Illuminati.Name = "Illuminati"
Illuminati.Parent = ScrollingFrame
Illuminati.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Illuminati.Position = UDim2.new(0.0093457941, 0, 0.0932345614, 0)
Illuminati.Size = UDim2.new(0, 419, 0, 36)
Illuminati.Font = Enum.Font.SourceSansBold
Illuminati.Text = "    Illuminati"
Illuminati.TextColor3 = Color3.fromRGB(255, 255, 255)
Illuminati.TextSize = 20.000
Illuminati.TextWrapped = true
Illuminati.TextXAlignment = Enum.TextXAlignment.Left

UICorner_8.Parent = Illuminati

MineCraftSteve.Name = "MineCraftSteve"
MineCraftSteve.Parent = ScrollingFrame
MineCraftSteve.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
MineCraftSteve.Position = UDim2.new(0.0093457941, 0, 0.108580746, 0)
MineCraftSteve.Size = UDim2.new(0, 419, 0, 36)
MineCraftSteve.Font = Enum.Font.SourceSansBold
MineCraftSteve.Text = "    I...Am Steve"
MineCraftSteve.TextColor3 = Color3.fromRGB(255, 255, 255)
MineCraftSteve.TextSize = 20.000
MineCraftSteve.TextWrapped = true
MineCraftSteve.TextXAlignment = Enum.TextXAlignment.Left
MineCraftSteve.MouseButton1Down:Connect(function()
local targetName = game.Players.LocalPlayer.Name
local player = game.Players:FindFirstChild(targetName)
function putTexture(part, frontF, backF, topF, bottomF, leftF, rightF, className)
	local faces = {"Front", "Back", "Top", "Bottom", "Left", "Right"}
	for i,f in pairs(faces) do
		local decal = Instance.new(className, part)
		if i == 1 then decal.Texture = frontF decal.Name = f end
		if i == 2 then decal.Texture = backF or frontF decal.Name = f  end
		if i == 3 then decal.Texture = topF or frontF decal.Name = f  end
		if i == 4 then decal.Texture = bottomF or frontF decal.Name = f end
		if i == 5 then decal.Texture = leftF or frontF decal.Name = f  end
		if i == 6 then decal.Texture = rightF or frontF decal.Name = f  end
		decal.Face = f
	end
	return part
end
function makeSquare(position, size, color, transparency, parent)
	local label = Instance.new("TextLabel", parent)
	label.Text = ""
	label.BorderSizePixel = 0
	label.BackgroundTransparency = transparency
	label.Position = position
	label.Size = size
	label.BackgroundColor3 = color
end
function putToolBarSlot(position, image)
	local playerGui = player:FindFirstChild("PlayerGui")
	if playerGui then
		local gui = playerGui:FindFirstChild("ToolBar") or Instance.new("ScreenGui", playerGui)
		gui.Name = "ToolBar"
		local slot = Instance.new("ImageLabel", gui)
		slot.Position = position
		slot.Size = UDim2.new(0, 32, 0, 32)
		slot.BackgroundTransparency = 1
		slot.ImageTransparency = 0
		slot.Image = image
		slot.ZIndex = 2
		
		makeSquare(UDim2.new(0, 0, 0, 0), UDim2.new(0, 32, 0, 32), 
			Color3.new(95/255, 89/255, 76/255), 0, slot)
		makeSquare(UDim2.new(0, 0, 0, 0), UDim2.new(0, 2, 0, 32), 
			Color3.new(0/255, 0/255, 0/255), 0.5, slot)
		makeSquare(UDim2.new(0, 2, 0, 0), UDim2.new(0, 30, 0, 2), 
			Color3.new(0/255, 0/255, 0/255), 0.5, slot)
		makeSquare(UDim2.new(0, -2, 0, -2), UDim2.new(0, 36, 0, 2), 
			Color3.new(106/255, 106/255, 106/255), 0, slot)
		makeSquare(UDim2.new(0, -2, 0, -2), UDim2.new(0, 2, 0, 36), 
			Color3.new(106/255, 106/255, 106/255), 0, slot)
		makeSquare(UDim2.new(0, 0, 0, 32), UDim2.new(0, 34, 0, 2), 
			Color3.new(130/255, 130/255, 130/255), 0, slot)
		makeSquare(UDim2.new(0, 32, 0, 0), UDim2.new(0, 2, 0, 34), 
			Color3.new(130/255, 130/255, 130/255), 0, slot)
		makeSquare(UDim2.new(0, -4, 0, -2), UDim2.new(0, 2, 0, 38), 
			Color3.new(130/255, 130/255, 130/255), 0, slot)
		makeSquare(UDim2.new(0, 34, 0, -2), UDim2.new(0, 2, 0, 36), 
			Color3.new(106/255, 106/255, 106/255), 0, slot)
		makeSquare(UDim2.new(0, -2, 0, 34), UDim2.new(0, 38, 0, 2), 
			Color3.new(106/255, 106/255, 106/255), 0, slot)
		makeSquare(UDim2.new(0, -4, 0, -4), UDim2.new(0, 40, 0, 2), 
			Color3.new(156/255, 156/255, 156/255), 0, slot)
	end
end
function divide(x, d)
	if x ~= 0 and d ~= 0 then
		return x/d
	else
		return x
	end
end -- so it doesn't divide by zero
function getDistance(v1, v2)
	return math.abs((Vector3.new(math.abs(v2.X - v1.X), math.abs(v2.Y - v1.Y), math.abs(v2.Z - v1.Z))).Magnitude)
end
function round(x)
  	if x%2 ~= 0.5 then
    	return math.floor(x+0.5)
  	end
  	return x-0.5
end
function weldTo(part1, part2)
	local weld = Instance.new("Weld", part1)
	weld.Part0 = part1
	weld.Part1 = part2
end
function getMagnitudeXZ(velocity)
	return math.abs(velocity.X) + math.abs(velocity.Z)
end
function placeBlock(block, cFPos)
	local blockPlaced = Instance.new("Part", workspace)
	blockPlaced.Material = "Fabric"
	blockPlaced.Anchored = true
	blockPlaced.Size = block.size
	blockPlaced.CFrame = cFPos
	putTexture(blockPlaced, block.frontTex, block.backTex, 
		block.topTex, block.bottomTex, block.leftTex, block.rightTex, "Texture")
	return blockPlaced
end
local toolBar = {
	Dirt = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://179655033",
		backTex = "rbxassetid://179655033",
		topTex = "rbxassetid://179655033",
		bottomTex = "rbxassetid://179655033",
		leftTex = "rbxassetid://179655033",
		rightTex = "rbxassetid://179655033"
	},
	Grass = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://96430337",
		backTex = "rbxassetid://96430337",
		topTex = "rbxassetid://96430265",
		bottomTex = "rbxassetid://179655033",
		leftTex = "rbxassetid://96430337",
		rightTex = "rbxassetid://96430337"
	},
	Stone = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://75880927",
		backTex = "rbxassetid://75880927",
		topTex = "rbxassetid://75880927",
		bottomTex = "rbxassetid://75880927",
		leftTex = "rbxassetid://75880927",
		rightTex = "rbxassetid://75880927"
	},
	Diamond_Ore = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://57928490",
		backTex = "rbxassetid://57928490",
		topTex = "rbxassetid://57928490",
		bottomTex = "rbxassetid://57928490",
		leftTex = "rbxassetid://57928490",
		rightTex = "rbxassetid://57928490"
	},
	Diamond_Block = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://56749955",
		backTex = "rbxassetid://56749955",
		topTex = "rbxassetid://56749955",
		bottomTex = "rbxassetid://56749955",
		leftTex = "rbxassetid://56749955",
		rightTex = "rbxassetid://56749955"
	},
	Wood_Planks = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://346201871",
		backTex = "rbxassetid://346201871",
		topTex = "rbxassetid://346201871",
		bottomTex = "rbxassetid://346201871",
		leftTex = "rbxassetid://346201871",
		rightTex = "rbxassetid://346201871"
	},
	Oak_Log = {
		size = Vector3.new(2.6, 2.6, 2.6),
		frontTex = "rbxassetid://310831812",
		backTex = "rbxassetid://310831812",
		topTex = "rbxassetid://152538557",
		bottomTex = "rbxassetid://152538557",
		leftTex = "rbxassetid://310831812",
		rightTex = "rbxassetid://310831812"
	}
}
if player then
	local char = player.Character
	if char then
		for _,cM in pairs(char:GetChildren()) do
			if cM.ClassName == "CharacterMesh" then cM:Destroy() end
		end
		
		--[]
		local gui = player.PlayerGui:FindFirstChild("ToolBar") or Instance.new("ScreenGui", player.PlayerGui)
		gui.Name = "ToolBar"
		
		makeSquare(UDim2.new(0.5, -166, 1, -111), UDim2.new(0, 364, 0, 44), 
			Color3.new(0/255, 0/255, 0/255), 0, gui)
		
		local blocks = {"Dirt", "Grass", "Stone", "Diamond_Ore", "Diamond_Block", "Wood_Planks", "Oak_Log"}
		for i = 1, 9 do
			if toolBar[blocks[i]] ~= nil then
				putToolBarSlot(UDim2.new(0.5, -160 + ((i-1)*40), 1, -105), toolBar[blocks[i]].frontTex)
			else
				putToolBarSlot(UDim2.new(0.5, -160 + ((i-1)*40), 1, -105), "")				
			end
		end	
		
		local humRootPart = char:WaitForChild("HumanoidRootPart")
		local head = char:WaitForChild("Head")
		local torso = char:WaitForChild("Torso")
		local lArm = char:WaitForChild("Left Arm")
		local rArm = char:WaitForChild("Right Arm")
		local lLeg = char:WaitForChild("Left Leg")
		local rLeg = char:WaitForChild("Right Leg")
		
		head.Size = Vector3.new(1.3, 1.3, 1.3)
		putTexture(head, "rbxassetid://38738031", "rbxassetid://36047330", 
			"rbxassetid://36047341", "rbxassetid://36047347",
			"rbxassetid://36047323", "rbxassetid://36047315", "Decal")
		head:WaitForChild("Mesh"):Destroy()
		head:WaitForChild("face"):Destroy()
		
		torso.Size = Vector3.new(1.3, 1.95, 0.65)
		putTexture(torso, "rbxassetid://38934753", "rbxassetid://38934731", 
			"rbxassetid://38934780", "rbxassetid://38934740",
			"rbxassetid://38934762", "rbxassetid://38934762", "Decal")
		
		lArm.Size = Vector3.new(0.65, 1.95, 0.65)
		putTexture(lArm, "rbxassetid://38934581", "rbxassetid://38934560", 
			"rbxassetid://38934613", "rbxassetid://38934568",
			"rbxassetid://38934601", "rbxassetid://38934591", "Decal")
		
		rArm.Size = Vector3.new(0.65, 1.95, 0.65)
		putTexture(rArm, "rbxassetid://38934560", "rbxassetid://38934581", 
			"rbxassetid://38934613", "rbxassetid://38934568",
			"rbxassetid://38934601", "rbxassetid://38934591", "Decal")
		
		lLeg.Size = Vector3.new(0.65, 1.95, 0.65)
		putTexture(lLeg, "rbxassetid://38936226", "rbxassetid://38936209", 
			"rbxassetid://38934719", "rbxassetid://38934712",
			"rbxassetid://38936255", "rbxassetid://38936242", "Decal")
		
		rLeg.Size = Vector3.new(0.65, 1.95, 0.65)
		putTexture(rLeg, "rbxassetid://38936209", "rbxassetid://38936226", 
			"rbxassetid://38934719", "rbxassetid://38934712",
			"rbxassetid://38936242", "rbxassetid://38936255", "Decal")
		
		char.Humanoid:ClearAllChildren()
		char.Animate:Remove()		
		
		-- now for the real stuff
		-- |
		-- |
		-- V
		Instance.new("BlockMesh", torso)
		Instance.new("BlockMesh", lArm)
		Instance.new("BlockMesh", rArm)
		Instance.new("BlockMesh", lLeg)
		Instance.new("BlockMesh", rLeg)
		
		local camera = workspace.Camera
		local camPart = Instance.new("Part", camera)
		camPart.Size = Vector3.new(0, 0, 0)
		camPart.CFrame = camera.CFrame
		camPart.Transparency = 1
		
		--[[local cameraHand = Instance.new("Part", camera)
		cameraHand.Size = Vector3.new(0.65, 1.95, 0.65)
		cameraHand.CanCollide = false
		cameraHand.Anchored = true
		cameraHand.Name = "CameraHand"
		putTexture(cameraHand, "rbxassetid://38934560", "rbxassetid://38934581", 
			"rbxassetid://38934613", "rbxassetid://38934568",
			"rbxassetid://38934601", "rbxassetid://38934591", "Decal")
		
		local cameraHandWeld = Instance.new("Motor6D", camPart)
		cameraHandWeld.Part0 = camPart
		cameraHandWeld.Part1 = cameraHand
		cameraHandWeld.C0 = CFrame.new(5, 0, 0)
		]]--
		
		local humanoid = char:WaitForChild("Humanoid")	
		humanoid.HipHeight = 0.3	

		local rootJoint = Instance.new("Motor6D", torso)
		rootJoint.Name = "RootJoint"
		rootJoint.Part0 = humRootPart
		rootJoint.Part1 = torso
		rootJoint.C1 = CFrame.new(0, 0.05, 0)
		
		local neck = Instance.new("Motor6D", torso)
		neck.Name = "Neck"
		neck.Part0 = head
		neck.Part1 = torso
		
		local lS = Instance.new("Motor6D", torso)
		lS.Name = "Left Shoulder"
		lS.Part0 = lArm
		lS.Part1 = torso
		lS.C0 = CFrame.new(-0.325, 0.975, 0) * CFrame.Angles(0, 0, 0)
		lS.C1 = CFrame.new(0.65, 0.975, 0)

		local rS = Instance.new("Motor6D", torso)
		rS.Name = "Right Shoulder"
		rS.Part0 = rArm
		rS.Part1 = torso
		rS.C0 = CFrame.new(-0.325, 0.975, 0) * CFrame.Angles(0, 0, 0)
		rS.C1 = CFrame.new(-0.65, 0.975, 0) * CFrame.Angles(0, -math.rad(180), 0)

		local lH = Instance.new("Motor6D", torso)
		lH.Name = "Left Hip"
		lH.Part0 = lLeg
		lH.Part1 = torso
		lH.C0 = CFrame.new(0, 0.975, 0)
		lH.C1 = CFrame.new(0.325, -0.975, 0) * CFrame.Angles(0, 0, 0)

		local rH = Instance.new("Motor6D", torso)
		rH.Name = "Right Hip"
		rH.Part0 = rLeg
		rH.Part1 = torso
		rH.C0 = CFrame.new(0, 0.975, 0)
		rH.C1 = CFrame.new(-0.325, -0.975, 0) * CFrame.Angles(0, -math.rad(180), 0)
		
		for _,p in pairs(char:GetChildren()) do
			if p.Name ~= "HumanoidRootPart" and p.ClassName == "Part" then
				local hit = Instance.new("Part", char)
				hit.Name = "DamagePart"
				hit.BrickColor = BrickColor.new("Bright red")
				hit.Material = "SmoothPlastic"
				hit.Transparency = 1
				hit.Size = Vector3.new(p.Size.X + 0.05, p.Size.Y + 0.05, p.Size.Z + 0.05)
				hit.CanCollide = false
				weldTo(hit, p)
			end
		end
		
		local ticks = 0
		local times = 0
		
		local walkAnim = 0
		local increaseWalkAnim = 1
		
		local idleAnimRotX = 0
		local idleAnimRotZ = 0
		local sneaking = 0
		
		local RS = game:GetService("RunService").RenderStepped
		local Mouse = player:GetMouse()		
		
		local oldHP = humanoid.Health
		local damageTime = 0
		
		local punchRotX = 0
		local punchRotY = 0
		local punchRotZ = 0			
		local punchSpeed = 0
		local punching = 0
		local selectedBlock = 8
		local punchEnded = 1
		local itemOnHand = nil
		
		local handItem = Instance.new("Part", char)
		handItem.Name = "HandItem"
		handItem.Size = Vector3.new(0.52, 0.52, 0.52)
		handItem.Transparency = 1	
		handItem.CanCollide = false
		
		local handItemWeld = Instance.new("Weld", char)
		handItemWeld.Part0 = handItem
		handItemWeld.Part1 = lArm
		handItemWeld.C1 = CFrame.new(0, -0.9, -0.6) * CFrame.Angles(math.rad(-10), math.rad(45), 0)	
		
		local sound = Instance.new("Sound", char)
		sound.Name = "Hurt"
		sound.Volume = 10
		sound.SoundId = "rbxassetid://535690488"		
		
		local facesToResize = {"Front", "Back", "Left", "Right", "Bottom", "Top"}
		Mouse.Button1Down:connect(function()
			if punchEnded == 1 then punching = 1 end
			if Mouse.Target then
				if getDistance(head.CFrame.p, Mouse.Hit.p) <= 10.4 then
					local humanoid = Mouse.Target.Parent:FindFirstChild("Humanoid")
					if humanoid then
						humanoid.Health = humanoid.Health - 10
						local parts = Mouse.Target.Parent:GetChildren()
						for _,p in pairs(parts) do
							if p.ClassName == "Part" then
								p.Velocity = Vector3.new(p.Velocity.X + (head.CFrame.lookVector.X * 18), p.Velocity.Y + (head.CFrame.lookVector.Y * 18) + 8, p.Velocity.Z + (head.CFrame.lookVector.Z * 18))
							end
						end
						return
					end
					local x = Mouse.Target.CFrame.p.X
					local y = Mouse.Target.CFrame.p.Y
					local z = Mouse.Target.CFrame.p.Z
					if Mouse.TargetSurface.Name == "Right" then x = x + 2.6 end
					if Mouse.TargetSurface.Name == "Left" then x = x - 2.6 end
					if Mouse.TargetSurface.Name == "Top" then y = y + 2.6 end
					if Mouse.TargetSurface.Name == "Bottom" then y = y - 2.6 end
					if Mouse.TargetSurface.Name == "Back" then z = z + 2.6 end
					if Mouse.TargetSurface.Name == "Front" then z = z - 2.6 end
					if Mouse.Target.Size.X > 2.6 or Mouse.Target.Size.Y > 2.6 or Mouse.Target.Size.Z > 2.6 then
						x = Mouse.Hit.p.X
						y = Mouse.Hit.p.Y
						z = Mouse.Hit.p.Z
					end
	--				local x = round(math.abs(mouseX)/2.6)*2.6
	--				local y = round(math.abs(mouseY)/2.6)*2.6
	--				local z = round(math.abs(mouseZ)/2.6)*2.6
	--				if Mouse.Hit.p.X < 0 then x = x * -1 end
	--				if Mouse.Hit.p.Y < 0 then y = y * -1 end
	--				if Mouse.Hit.p.Z < 0 then z = z * -1 end
					if selectedBlock == 0 then
						local blk = placeBlock(toolBar.Dirt, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 1 then
						local blk = placeBlock(toolBar.Grass, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 2 then
						local blk = placeBlock(toolBar.Stone, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 3 then
						local blk = placeBlock(toolBar.Diamond_Ore, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 4 then
						local blk = placeBlock(toolBar.Diamond_Block, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 5 then
						local blk = placeBlock(toolBar.Wood_Planks, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 6 then
						local blk = placeBlock(toolBar.Oak_Log, CFrame.new(x, y, z))
						for _,f in pairs(facesToResize) do
							blk:WaitForChild(f).StudsPerTileU = 2.6
							blk:WaitForChild(f).StudsPerTileV = 2.6
						end
					elseif selectedBlock == 7 or selectedBlock == 8 then
						if Mouse.Target.Size.X <= 10 and Mouse.Target.Size.Y <= 10 and Mouse.Target.Size.Z <= 10 then
							Mouse.Target.Parent = nil
						end
					end
				end
			end
		end)		
		
		local hasItemOnHand = 0
		local hi = 0
		-- selection thingy
		local selectLabel = Instance.new("TextLabel", gui)
		selectLabel.Size = UDim2.new(0, 32, 0, 32)
		selectLabel.Position = UDim2.new(0.5, -160 + (selectedBlock*40), 1, -105)
		selectLabel.BackgroundTransparency = 0.5
		selectLabel.BackgroundColor3 = Color3.new(1, 1, 1)
		selectLabel.BorderSizePixel = 0
		selectLabel.Text = ""
		selectLabel.ZIndex = 3
		--	
		Mouse.KeyDown:connect(function(key)
			if key == "q" then
				sneaking = 1
				humanoid.WalkSpeed = humanoid.WalkSpeed / 2
				rootJoint.C1 = CFrame.new(0, 0.325, 0) * CFrame.Angles(math.rad(sneaking*45), 0, 0)
				lH.C0 = CFrame.new(0, 0.975, 0) * CFrame.Angles(-math.rad(sneaking*45), 0, 0)
				rH.C0 = CFrame.new(0, 0.975, 0) * CFrame.Angles(math.rad(sneaking*45), 0, 0)
				print("Sneaking...")
			end
			if key == "8" then 
				selectedBlock = 7
				itemOnHand = nil
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				if hasItemOnHand == 1 then hi = 1 end
			end
			if key == "9" then 
				selectedBlock = 8
				itemOnHand = nil
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				if hasItemOnHand == 1 then hi = 1 end
			end
			if key == "1" then 
				selectedBlock = 0
				itemOnHand = toolBar.Dirt
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if key == "2" then 
				selectedBlock = 1 
				itemOnHand = toolBar.Grass
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if key == "3" then 
				selectedBlock = 2 
				itemOnHand = toolBar.Stone
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if key == "4" then 
				selectedBlock = 3 
				itemOnHand = toolBar.Diamond_Ore
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if key == "5" then 
				selectedBlock = 4 
				itemOnHand = toolBar.Diamond_Block
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if key == "6" then 
				selectedBlock = 5 
				itemOnHand = toolBar.Wood_Planks
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if key == "7" then 
				selectedBlock = 6 
				itemOnHand = toolBar.Oak_Log
				for _,d in pairs(handItem:GetChildren()) do
					d:Destroy()
				end
				putTexture(handItem, itemOnHand.frontTex, itemOnHand.backTex,
					itemOnHand.topTex, itemOnHand.bottomTex,
					itemOnHand.leftTex, itemOnHand.rightTex, "Texture")
				for _,f in pairs(facesToResize) do
					handItem:WaitForChild(f).StudsPerTileU = 0.52
					handItem:WaitForChild(f).StudsPerTileV = 0.52
				end
			end
			if (key == "0" or key == "1" or key == "2" 
				or key == "3" or key == "4" or key == "5"
				or key == "6" or key == "7") and hasItemOnHand == 0 then hi = 1 end
			selectLabel.Position = UDim2.new(0.5, -160 + ((selectedBlock)*40), 1, -105)
		end)
		
		Mouse.KeyUp:connect(function(key)
			if key == "q" then
				sneaking = 0
				humanoid.WalkSpeed = humanoid.WalkSpeed * 2
				rootJoint.C1 = CFrame.new(0, 0.05, 0) * CFrame.Angles(0, 0, 0)
				lH.C0 = CFrame.new(0, 0.975, 0) * CFrame.Angles(0, 0, 0)
				rH.C0 = CFrame.new(0, 0.975, 0) * CFrame.Angles(0, 0, 0)
				print("Stopped sneaking...")
			end
		end)
		
		while RS:wait() do
			if itemOnHand ~= nil then 
				hasItemOnHand = 1 
				handItem.Transparency = 0
			else 
				hasItemOnHand = 0 
				handItem.Transparency = 1
			end
			if humanoid.Health < oldHP then
				damageTime = 60
				sound:Play()
			end
			oldHP = humanoid.Health
			if damageTime > 0 and humanoid.Health > 0 then
				for _,p in pairs(char:GetChildren()) do
					if p.Name ~= "HumanoidRootPart" and p.ClassName == "Part" then
						if p.Name == "DamagePart" then
							p.Transparency = 0.5
						end
					end
				end
				damageTime = damageTime - 2
				if damageTime <= 0 then
					for _,p in pairs(char:GetChildren()) do
						if p.Name ~= "HumanoidRootPart" and p.ClassName == "Part" then
							if p.Name == "DamagePart" then
								p.Transparency = 1
							end
						end
					end
				end
			end
			camPart.CFrame = camera.CFrame
			neck.C1 = CFrame.new(0, 0.975, 0) * CFrame.fromEulerAnglesXYZ(math.rad(sneaking*45), math.rad(camPart.Orientation.Y - torso.Orientation.Y), 0)
			neck.C0 = CFrame.new(0, -0.65, 0) * CFrame.Angles(-math.rad(camPart.Orientation.X - torso.Orientation.X - (sneaking*45)), 0, 0)		
			
			if getMagnitudeXZ(torso.Velocity) > 1 then
				if walkAnim >= 1 then
					increaseWalkAnim = -1
				elseif walkAnim <= -1 then
					increaseWalkAnim = 1
				end
				walkAnim = walkAnim + (increaseWalkAnim/(10+(sneaking*20)))
			else
				walkAnim = 0
			end
			
			--lH.C0 = CFrame.new(0, 0.975, 0) * CFrame.Angles(-math.rad(sneaking*45), 0, 0)
			--rH.C0 = CFrame.new(0, 0.975, 0) * CFrame.Angles(math.rad(sneaking*45), 0, 0)
			lH.C0 = lH.C0:lerp(CFrame.new(0, 0.975, 0) * CFrame.Angles(-math.rad(sneaking*45) + math.rad(damageTime*1.5) + math.rad(walkAnim*getMagnitudeXZ(torso.Velocity)*5/(1+sneaking)), 0, 0), 0.1)
	    	rH.C0 = rH.C0:lerp(CFrame.new(0, 0.975, 0) * CFrame.Angles(math.rad(sneaking*45) + math.rad(damageTime*1.5) + math.rad(walkAnim*getMagnitudeXZ(torso.Velocity)*5/(1+sneaking)), 0, 0), 0.1)
			--
			--rootJoint.C0 = CFrame.new(0, 0, 0) * CFrame.Angles(0, 0, 0)
			--print(math.abs(head.Orientation.Y) - math.abs(humRootPart.Orientation.Y))
			--if (head.Orientation.Y * 2) - (head.Orientation.Y + torso.Orientation.Y) > 45 then
				--humRootPart.CFrame = humRootPart.CFrame * CFrame.Angles(0, math.rad(-45 + head.Orientation.Y), 0)
				--print("-45")
			--end
			--if (head.Orientation.Y * 2) - (head.Orientation.Y + torso.Orientation.Y) < -45 then
				--humRootPart.CFrame = humRootPart.CFrame * CFrame.Angles(0, math.rad(45 + head.Orientation.Y), 0)
				--print("45")
			--end
			
			--move these arms
			rootJoint.C1 = rootJoint.C1:lerp(CFrame.new(0, 0.325, 0) * CFrame.Angles(math.rad(sneaking*45), math.rad(punchRotY), 0), 0.2)
			
	    	lS.C0 = lS.C0:lerp(CFrame.new(-0.325, 0.975, 0) * CFrame.Angles(idleAnimRotX/20 + math.rad(-hasItemOnHand*10) + math.rad(punchRotX) + math.rad(damageTime*1.5) + math.rad(walkAnim*getMagnitudeXZ(torso.Velocity)*5/(1+sneaking)), 0, math.rad(punchRotZ) + idleAnimRotZ/20), 0.025+(math.min(1, getMagnitudeXZ(torso.Velocity))/12) + divide(punchSpeed, 6) + hi)
	    	rS.C0 = rS.C0:lerp(CFrame.new(-0.325, 0.975, 0) * CFrame.Angles(idleAnimRotX/20 + math.rad(damageTime*1.5) + math.rad(walkAnim*getMagnitudeXZ(torso.Velocity)*5/(1+sneaking)), 0, idleAnimRotZ/20), 0.025+(math.min(1, getMagnitudeXZ(torso.Velocity))/12))
			if punching == 1 and punchEnded == 1 then
				punching = 0
				print("steve uses punch!!")
				local coPunch = coroutine.wrap(function()
					punchEnded = 0
					punchSpeed = 1
					punchRotX = -60
					punchRotY = -8
					punchRotZ = -35
					wait(0.075)
					punchSpeed = 1
					punchRotX = -75
					punchRotY = 8
					punchRotZ = 40
					wait(0.075)
					punchSpeed = 1
					punchRotX = -20
					punchRotZ = 40
					wait(0.075)
					punchSpeed = 3.5
					punchRotX = 0
					punchRotY = 0
					punchRotZ = 0
					punchEnded = 1
					wait(0.06)	
					punchSpeed = 0			
				end)
				coPunch()
			end			
			if ticks > 20 then
				ticks = 0
				if times == 0 then
					times = times + 1
					idleAnimRotX = -1
					idleAnimRotZ = 0
				elseif times == 1 then
					times = times + 1
					idleAnimRotX = -0.75
					idleAnimRotZ = -0.75
				elseif times == 2 then
					times = times + 1
					idleAnimRotX = 0
					idleAnimRotZ = -1
				elseif times == 3 then
					times = times + 1
					idleAnimRotX = 0.75
					idleAnimRotZ = -0.75
					--idleAnimRotX = 0.75
					--idleAnimRotZ = -0
				elseif times == 4 then
					times = times + 1
					idleAnimRotX = 1
					idleAnimRotZ = 0
					--idleAnimRotX = 1
					--idleAnimRotZ = 0
				elseif times == 5 then
					times = times + 1
					idleAnimRotX = 0.75
					idleAnimRotZ = 0.75
				elseif times == 6 then
					times = times + 1
					idleAnimRotX = 0
					idleAnimRotZ = 1
				elseif times == 7 then
					times = 0
					idleAnimRotX = -0.75
					idleAnimRotZ = 0.75
				end
			end
			if hi == 1 then hi = 0 end
			ticks = ticks + 1
		end
	end
end
end)

UICorner_9.Parent = MineCraftSteve

Goner.Name = "Goner"
Goner.Parent = ScrollingFrame
Goner.BackgroundColor3 = Color3.fromRGB(225, 193, 110)
Goner.Position = UDim2.new(0.0093457941, 0, 0.0625422001, 0)
Goner.Size = UDim2.new(0, 419, 0, 36)
Goner.Font = Enum.Font.SourceSansBold
Goner.Text = "    Goner"
Goner.TextColor3 = Color3.fromRGB(255, 255, 255)
Goner.TextSize = 20.000
Goner.TextWrapped = true
Goner.TextXAlignment = Enum.TextXAlignment.Left

UICorner_10.Parent = Goner

HolyWrench.Name = "HolyWrench"
HolyWrench.Parent = ScrollingFrame
HolyWrench.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
HolyWrench.Position = UDim2.new(0.0093457941, 0, 0.139630005, 0)
HolyWrench.Size = UDim2.new(0, 419, 0, 36)
HolyWrench.Font = Enum.Font.SourceSansBold
HolyWrench.Text = "    Holy Wrench"
HolyWrench.TextColor3 = Color3.fromRGB(255, 255, 255)
HolyWrench.TextSize = 20.000
HolyWrench.TextWrapped = true
HolyWrench.TextXAlignment = Enum.TextXAlignment.Left
HolyWrench.MouseButton1Down:Connect(function()
script.Parent = workspace.CurrentCamera
local plr = game:GetService("Players").LocalPlayer

local tool = Instance.new("Tool",plr:WaitForChild("Backpack"))
tool.Grip = CFrame.new(0,-0.8,-0.2) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0))
tool.Name = "bluE"

local part = Instance.new("Part",tool)
part.Name = "Handle"
part.Size = Vector3.new(4,6,4)
part.TopSurface = "Smooth"
part.BottomSurface = "Smooth"
part.CanCollide = false
part:BreakJoints()

local mesh = Instance.new("SpecialMesh",part)
mesh.MeshId = "rbxassetid://431003868" --mesh.MeshId = "rbxassetid://132920499"
mesh.TextureId = "rbxassetid://430627740" --"http://www.roblox.com/asset/?id=134479421"
mesh.Scale = Vector3.new(2,2,2)

local sound = Instance.new("Sound",part)
sound.SoundId = "rbxassetid://138093488"
sound.Volume = 3

local sound2 = Instance.new("Sound",part)
sound2.SoundId = "rbxassetid://280667448"
sound2.Volume = 5

local sound3 = Instance.new("Sound",part)
sound3.SoundId = "rbxassetid://130934652"
sound3.Pitch = 0.9
sound3.Volume = 10

local sound4 = Instance.new("Sound",part)
sound4.SoundId = "rbxassetid://258057783"
sound4.Volume = 10

local sound5 = Instance.new("Sound",part)
sound5.SoundId = "rbxassetid://138093488"
sound5.Volume = 50

local sound6 = Instance.new("Sound",part)
sound6.SoundId = "rbxassetid://906084456"
sound6.Volume = 10
sound6.TimePosition = 2

function firstHum(target)
	for i,v in pairs(target:GetChildren()) do
		if v:IsA("Humanoid") then
			return v
		end
	end
	return nil
end

local slap = false
local cd = false

plr:GetMouse().Button1Down:connect(function()
	if tool.Parent == plr.Character then
		if slap == false then
			slap = true
			sound2:Play()
			local str = Instance.new("StringValue")
			str.Name = "toolanim"
			str.Value = "Slash"
			str.Parent = tool
			wait(1)
			slap = false
		end
	end
end)

part.Touched:connect(function(hit)
	if slap == true then
		if cd == false then
			if not hit:IsDescendantOf(plr.Character) then
				if hit.Parent:IsA("Model") then
					local fhum = firstHum(hit.Parent)
					if fhum then
						cd = true
						fhum.PlatformStand = true
						sound:Play()
						local con1
						con1 = game:GetService("RunService").Heartbeat:connect(function()
							fhum.PlatformStand = true
						end)
						wait(0.1)
						local vel = Instance.new("BodyVelocity",hit)
						vel.Velocity = ((hit.Position - plr.Character:WaitForChild("HumanoidRootPart").Position).unit + Vector3.new(0,0.5,0))*50
						vel.MaxForce = Vector3.new(10000000,10000000,10000000)
						wait(1)
						cd = false
						vel:Destroy()
						local vel2 = Instance.new("BodyVelocity",hit)
						vel2.Velocity = Vector3.new(0,12.5,0)
						vel2.MaxForce = Vector3.new(10000000,10000000,10000000)
						local p2 = Instance.new("Part",hit)
						p2.Anchored = true
						p2.Transparency = 0.6
						p2.CanCollide = false
						p2.Size = Vector3.new(0.2,0.2,0.2)
						p2.CFrame = CFrame.new(hit.CFrame.p) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0))
						p2.BrickColor = BrickColor.new("New Yeller")
						p2.Material = "Neon"
						local m2 = Instance.new("CylinderMesh",p2)
						m2.Scale = Vector3.new(60,10000,60)
						local scln = sound3:Clone()
						scln.Parent = hit
						scln:Play()
						local con2
						con2 = game:GetService("RunService").Heartbeat:connect(function()
							p2.CFrame = CFrame.new(hit.CFrame.p) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(0))
						end)
						wait(7)
						vel2.Velocity = Vector3.new(0,0,0)
						wait(0.5)
						scln:Stop()
						local scln3 = sound5:Clone()
						scln3.Parent = hit
						scln3:Play()
						wait(1)
						local bav = Instance.new("BodyAngularVelocity",hit)
						bav.AngularVelocity = Vector3.new(math.random(0,360),math.random(0,360),math.random(0,360))
						vel2.Velocity = Vector3.new(0,-250,0)
						p2.BrickColor = BrickColor.new("Really red")
						local scln6 = sound6:Clone()
						scln6.Parent = hit
						scln6:Play()
						local continue = false
						local htc
						htc = hit.Touched:connect(function(hitp)
							if not hitp:IsDescendantOf(hit.Parent) then
								continue = true
								scln6:Stop()
								vel2:Destroy()
								con2:Disconnect()
								con1:Disconnect()
								htc:Disconnect()
								p2:Destroy()
							end
						end)
						repeat wait() until continue == true
						local ctab = {}
						for i=1,4 do
							local p = Instance.new("Part",hit)
							p.Size = Vector3.new(30,30,30)
							p.Anchored = true
							p.CanCollide = false
							p.TopSurface = "Smooth"
							p.BottomSurface = "Smooth"
							p.Color = Color3.fromRGB(255,math.random(0,255),0)
							p.CFrame = hit.CFrame
							local con
							con = game:GetService("RunService").Heartbeat:connect(function()
								p.CFrame = p.CFrame * CFrame.Angles(math.rad(math.random(0,360)),math.rad(math.random(0,360)),math.rad(math.random(0,360)))
								p.Transparency = p.Transparency + 0.01
								if p.Transparency >= 1 then
									con:Disconnect()
								end
							end)
							table.insert(ctab,con)
						end	
						Instance.new("Explosion",workspace).Position = hit.Position
						local scln2 = sound4:Clone()
						scln2.Parent = hit
						scln2:Play()
						vel2:Destroy()
						hit.Parent:BreakJoints()
						repeat wait() until not hit:IsDescendantOf(workspace)
						con2:Disconnect()
					end
				end
			end
		end
	end
end)
end)

UICorner_11.Parent = HolyWrench

Baseplate.Name = "Baseplate"
Baseplate.Parent = ScrollingFrame
Baseplate.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Baseplate.Position = UDim2.new(0.0093457941, 0, 0.154976189, 0)
Baseplate.Size = UDim2.new(0, 419, 0, 36)
Baseplate.Font = Enum.Font.SourceSansBold
Baseplate.Text = "    Create Baseplate"
Baseplate.TextColor3 = Color3.fromRGB(255, 255, 255)
Baseplate.TextSize = 20.000
Baseplate.TextWrapped = true
Baseplate.TextXAlignment = Enum.TextXAlignment.Left
Baseplate.MouseButton1Down:Connect(function()
	local pt = Instance.new("Part")
	pt.BrickColor = BrickColor.new("Silver")
	pt.Anchored = true
	pt.CanCollide = true
	pt.BottomSurface = "Weld"
	pt.Parent = workspace
	pt.Name = (math.random(1,1000000))
	pt.Size = Vector3.new(1000, 1, 1000)
end)

UICorner_12.Parent = Baseplate

FlingGUI.Name = "FlingGUI"
FlingGUI.Parent = ScrollingFrame
FlingGUI.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
FlingGUI.Position = UDim2.new(0.0093457941, 0, 0.170322359, 0)
FlingGUI.Size = UDim2.new(0, 419, 0, 36)
FlingGUI.Font = Enum.Font.SourceSansBold
FlingGUI.Text = "    Fling GUI"
FlingGUI.TextColor3 = Color3.fromRGB(255, 255, 255)
FlingGUI.TextSize = 20.000
FlingGUI.TextWrapped = true
FlingGUI.TextXAlignment = Enum.TextXAlignment.Left

UICorner_13.Parent = FlingGUI

TOPk3k.Name = "TOPk3k"
TOPk3k.Parent = ScrollingFrame
TOPk3k.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
TOPk3k.Position = UDim2.new(0.0093457941, 0, 0.199944049, 0)
TOPk3k.Size = UDim2.new(0, 419, 0, 36)
TOPk3k.Font = Enum.Font.SourceSansBold
TOPk3k.Text = "     TOPk3k"
TOPk3k.TextColor3 = Color3.fromRGB(255, 255, 255)
TOPk3k.TextSize = 20.000
TOPk3k.TextWrapped = true
TOPk3k.TextXAlignment = Enum.TextXAlignment.Left

UICorner_14.Parent = TOPk3k

KFC.Name = "KFC"
KFC.Parent = ScrollingFrame
KFC.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
KFC.Position = UDim2.new(0.0093457941, 0, 0.230636418, 0)
KFC.Size = UDim2.new(0, 419, 0, 36)
KFC.Font = Enum.Font.SourceSansBold
KFC.Text = "    KFC"
KFC.TextColor3 = Color3.fromRGB(255, 255, 255)
KFC.TextSize = 20.000
KFC.TextWrapped = true
KFC.TextXAlignment = Enum.TextXAlignment.Left

UICorner_15.Parent = KFC

TrollingGUI.Name = "TrollingGUI"
TrollingGUI.Parent = ScrollingFrame
TrollingGUI.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
TrollingGUI.Position = UDim2.new(0.0093457941, 0, 0.18459788, 0)
TrollingGUI.Size = UDim2.new(0, 419, 0, 36)
TrollingGUI.Font = Enum.Font.SourceSansBold
TrollingGUI.Text = "    Trolling GUI"
TrollingGUI.TextColor3 = Color3.fromRGB(255, 255, 255)
TrollingGUI.TextSize = 20.000
TrollingGUI.TextWrapped = true
TrollingGUI.TextXAlignment = Enum.TextXAlignment.Left

UICorner_16.Parent = TrollingGUI

InfYield.Name = "InfYield"
InfYield.Parent = ScrollingFrame
InfYield.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
InfYield.Position = UDim2.new(0.0093457941, 0, 0.215290248, 0)
InfYield.Size = UDim2.new(0, 419, 0, 36)
InfYield.Font = Enum.Font.SourceSansBold
InfYield.Text = "    Infinite Yield"
InfYield.TextColor3 = Color3.fromRGB(255, 255, 255)
InfYield.TextSize = 20.000
InfYield.TextWrapped = true
InfYield.TextXAlignment = Enum.TextXAlignment.Left

UICorner_17.Parent = InfYield

SuTart.Name = "SuTart"
SuTart.Parent = ScrollingFrame
SuTart.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
SuTart.Position = UDim2.new(0.0093457941, 0, 0.124283813, 0)
SuTart.Size = UDim2.new(0, 419, 0, 36)
SuTart.Font = Enum.Font.SourceSansBold
SuTart.Text = "    Su Tart"
SuTart.TextColor3 = Color3.fromRGB(255, 255, 255)
SuTart.TextSize = 20.000
SuTart.TextWrapped = true
SuTart.TextXAlignment = Enum.TextXAlignment.Left

UICorner_18.Parent = SuTart

Backrooms.Name = "Backrooms"
Backrooms.Parent = ScrollingFrame
Backrooms.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Backrooms.Position = UDim2.new(0.00934579596, 0, 0.261328787, 0)
Backrooms.Size = UDim2.new(0, 419, 0, 36)
Backrooms.Font = Enum.Font.SourceSansBold
Backrooms.Text = "    The Backrooms"
Backrooms.TextColor3 = Color3.fromRGB(255, 255, 255)
Backrooms.TextSize = 20.000
Backrooms.TextWrapped = true
Backrooms.TextXAlignment = Enum.TextXAlignment.Left

UICorner_19.Parent = Backrooms

NexPluviaAdmin.Name = "NexPluviaAdmin"
NexPluviaAdmin.Parent = ScrollingFrame
NexPluviaAdmin.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
NexPluviaAdmin.Position = UDim2.new(0.00934579596, 0, 0.276674956, 0)
NexPluviaAdmin.Size = UDim2.new(0, 419, 0, 36)
NexPluviaAdmin.Font = Enum.Font.SourceSansBold
NexPluviaAdmin.Text = "    Nex Pluvia Admin"
NexPluviaAdmin.TextColor3 = Color3.fromRGB(255, 255, 255)
NexPluviaAdmin.TextSize = 20.000
NexPluviaAdmin.TextWrapped = true
NexPluviaAdmin.TextXAlignment = Enum.TextXAlignment.Left

UICorner_20.Parent = NexPluviaAdmin

FunnyVest.Name = "FunnyVest"
FunnyVest.Parent = ScrollingFrame
FunnyVest.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
FunnyVest.Position = UDim2.new(0.00934579596, 0, 0.292021126, 0)
FunnyVest.Size = UDim2.new(0, 419, 0, 36)
FunnyVest.Font = Enum.Font.SourceSansBold
FunnyVest.Text = "    Suicide Vest"
FunnyVest.TextColor3 = Color3.fromRGB(255, 255, 255)
FunnyVest.TextSize = 20.000
FunnyVest.TextWrapped = true
FunnyVest.TextXAlignment = Enum.TextXAlignment.Left

UICorner_21.Parent = FunnyVest

Nuke.Name = "Nuke"
Nuke.Parent = ScrollingFrame
Nuke.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Nuke.Position = UDim2.new(0.00934579596, 0, 0.321642816, 0)
Nuke.Size = UDim2.new(0, 419, 0, 36)
Nuke.Font = Enum.Font.SourceSansBold
Nuke.Text = "    Nuclear Bomb"
Nuke.TextColor3 = Color3.fromRGB(255, 255, 255)
Nuke.TextSize = 20.000
Nuke.TextWrapped = true
Nuke.TextXAlignment = Enum.TextXAlignment.Left
Nuke.MouseButton1Down:Connect(function()
a = game.Lighting.Ambient
music = Instance.new("Sound")
music.Parent = game.Workspace
music.SoundId = "rbxassetid://199837904"
music.Volume = 10
music.PlaybackSpeed = 0.9
music.Playing = true
h = Instance.new("Hint")
h.Parent = game.Workspace 
h.Text = "Tactical Nuke Incoming!!!"
wait(3)
 
for i =1 , 3 do
	wait(0.5)
	game.Lighting.Ambient = Color3.new(255, 0, 0)
	wait(0.5)
	game.Lighting.Ambient = a
end
h:Remove()
cce = Instance.new("ColorCorrectionEffect",game.Lighting)
cce.Brightness = 0
for i=1, 10 do
wait(0.1)
cce.Brightness = cce.Brightness + 0.1
end
getplayers = game.Players:GetChildren()
for a=1, #getplayers do
wait(0.01)
char = getplayers[a].Character
char.Humanoid.Health = 0
end
wait(1)
cce:Destroy()
end)

UICorner_22.Parent = Nuke

Stand.Name = "Stand"
Stand.Parent = ScrollingFrame
Stand.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Stand.Position = UDim2.new(0.00934579596, 0, 0.352335185, 0)
Stand.Size = UDim2.new(0, 419, 0, 36)
Stand.Font = Enum.Font.SourceSansBold
Stand.Text = "    Stand"
Stand.TextColor3 = Color3.fromRGB(255, 255, 255)
Stand.TextSize = 20.000
Stand.TextWrapped = true
Stand.TextXAlignment = Enum.TextXAlignment.Left

UICorner_23.Parent = Stand

c00lify.Name = "c00lify"
c00lify.Parent = ScrollingFrame
c00lify.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
c00lify.Position = UDim2.new(0.00934579596, 0, 0.306296647, 0)
c00lify.Size = UDim2.new(0, 419, 0, 36)
c00lify.Font = Enum.Font.SourceSansBold
c00lify.Text = "    c00lify"
c00lify.TextColor3 = Color3.fromRGB(255, 255, 255)
c00lify.TextSize = 20.000
c00lify.TextWrapped = true
c00lify.TextXAlignment = Enum.TextXAlignment.Left
c00lify.MouseButton1Down:Connect(function()
decalID = 158118263
function exPro(root)
for _, v in pairs(root:GetChildren()) do
if v:IsA("Decal") and v.Texture ~= "http://www.roblox.com/asset/?id="..decalID then
v.Parent = nil
elseif v:IsA("BasePart") then
v.Material = "Plastic"
v.Transparency = 0
local One = Instance.new("Decal", v)
local Two = Instance.new("Decal", v)
local Three = Instance.new("Decal", v)
local Four = Instance.new("Decal", v)
local Five = Instance.new("Decal", v)
local Six = Instance.new("Decal", v)
One.Texture = "http://www.roblox.com/asset/?id="..decalID
Two.Texture = "http://www.roblox.com/asset/?id="..decalID
Three.Texture = "http://www.roblox.com/asset/?id="..decalID
Four.Texture = "http://www.roblox.com/asset/?id="..decalID
Five.Texture = "http://www.roblox.com/asset/?id="..decalID
Six.Texture = "http://www.roblox.com/asset/?id="..decalID
One.Face = "Front"
Two.Face = "Back"
Three.Face = "Right"
Four.Face = "Left"
Five.Face = "Top"
Six.Face = "Bottom"
end
exPro(v)
end
end
function asdf(root)
for _, v in pairs(root:GetChildren()) do
asdf(v)
end
end
exPro(game.Workspace)
asdf(game.Workspace)

local s = Instance.new("Sky")
s.Name = "Sky"
s.Parent = game.Lighting
local skyboxID = 158118263
s.SkyboxBk = "http://www.roblox.com/asset/?id="..skyboxID
s.SkyboxDn = "http://www.roblox.com/asset/?id="..skyboxID
s.SkyboxFt = "http://www.roblox.com/asset/?id="..skyboxID
s.SkyboxLf = "http://www.roblox.com/asset/?id="..skyboxID
s.SkyboxRt = "http://www.roblox.com/asset/?id="..skyboxID
s.SkyboxUp = "http://www.roblox.com/asset/?id="..skyboxID
game.Lighting.TimeOfDay = 12	

for i, v in pairs(game.Players:GetChildren()) do
emit = Instance.new("ParticleEmitter")
emit.Parent = v.Character.Torso
emit.Texture = "http://www.roblox.com/asset/?id=158118263"
emit.VelocitySpread = 20
end
for i, v in pairs(game.Players:GetChildren()) do
emit = Instance.new("ParticleEmitter")
emit.Parent = v.Character.Torso
emit.Texture = "http://www.roblox.com/asset/?id=158118263"
emit.VelocitySpread = 20
end
for i, v in pairs(game.Players:GetChildren()) do
emit = Instance.new("ParticleEmitter")
emit.Parent = v.Character.Torso
emit.Texture = "http://www.roblox.com/asset/?id=158118263"
emit.VelocitySpread = 20
end
end)

UICorner_24.Parent = c00lify

clownvan.Name = "clown van"
clownvan.Parent = ScrollingFrame
clownvan.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
clownvan.Position = UDim2.new(0.00934579596, 0, 0.336989015, 0)
clownvan.Size = UDim2.new(0, 419, 0, 36)
clownvan.Font = Enum.Font.SourceSansBold
clownvan.Text = "	clown van"
clownvan.TextColor3 = Color3.fromRGB(255, 255, 255)
clownvan.TextSize = 20.000
clownvan.TextWrapped = true
clownvan.TextXAlignment = Enum.TextXAlignment.Left
clownvan.MouseButton1Down:Connect(function()
	loadstring(game:HttpGet("https://rawscripts.net/raw/Universal-Script-2017-kidnap-van-thingy-41933"))()
end)

UICorner_25.Parent = clownvan

VrSword.Name = "VrSword"
VrSword.Parent = ScrollingFrame
VrSword.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
VrSword.Position = UDim2.new(0.00934579596, 0, 0.443698496, 0)
VrSword.Size = UDim2.new(0, 419, 0, 36)
VrSword.Font = Enum.Font.SourceSansBold
VrSword.Text = "    VR Sword"
VrSword.TextColor3 = Color3.fromRGB(255, 255, 255)
VrSword.TextSize = 20.000
VrSword.TextWrapped = true
VrSword.TextXAlignment = Enum.TextXAlignment.Left

UICorner_26.Parent = VrSword

ParkourGod.Name = "ParkourGod"
ParkourGod.Parent = ScrollingFrame
ParkourGod.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
ParkourGod.Position = UDim2.new(0.00934579596, 0, 0.398730636, 0)
ParkourGod.Size = UDim2.new(0, 419, 0, 36)
ParkourGod.Font = Enum.Font.SourceSansBold
ParkourGod.Text = "    Parkour God"
ParkourGod.TextColor3 = Color3.fromRGB(255, 255, 255)
ParkourGod.TextSize = 20.000
ParkourGod.TextWrapped = true
ParkourGod.TextXAlignment = Enum.TextXAlignment.Left

UICorner_27.Parent = ParkourGod

ServerAdmin.Name = "ServerAdmin"
ServerAdmin.Parent = ScrollingFrame
ServerAdmin.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
ServerAdmin.Position = UDim2.new(0.00934579596, 0, 0.368038267, 0)
ServerAdmin.Size = UDim2.new(0, 419, 0, 36)
ServerAdmin.Font = Enum.Font.SourceSansBold
ServerAdmin.Text = "    Server Admin"
ServerAdmin.TextColor3 = Color3.fromRGB(255, 255, 255)
ServerAdmin.TextSize = 20.000
ServerAdmin.TextWrapped = true
ServerAdmin.TextXAlignment = Enum.TextXAlignment.Left

UICorner_28.Parent = ServerAdmin

Sniper.Name = "Sniper"
Sniper.Parent = ScrollingFrame
Sniper.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Sniper.Position = UDim2.new(0.00934579596, 0, 0.414076805, 0)
Sniper.Size = UDim2.new(0, 419, 0, 36)
Sniper.Font = Enum.Font.SourceSansBold
Sniper.Text = "    Sniper"
Sniper.TextColor3 = Color3.fromRGB(255, 255, 255)
Sniper.TextSize = 20.000
Sniper.TextWrapped = true
Sniper.TextXAlignment = Enum.TextXAlignment.Left

UICorner_29.Parent = Sniper

ElioBlasio.Name = "ElioBlasio"
ElioBlasio.Parent = ScrollingFrame
ElioBlasio.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
ElioBlasio.Position = UDim2.new(0.00934579596, 0, 0.474390864, 0)
ElioBlasio.Size = UDim2.new(0, 419, 0, 36)
ElioBlasio.Font = Enum.Font.SourceSansBold
ElioBlasio.Text = "    Elio Blasio"
ElioBlasio.TextColor3 = Color3.fromRGB(255, 255, 255)
ElioBlasio.TextSize = 20.000
ElioBlasio.TextWrapped = true
ElioBlasio.TextXAlignment = Enum.TextXAlignment.Left

UICorner_30.Parent = ElioBlasio

Ender.Name = "Ender"
Ender.Parent = ScrollingFrame
Ender.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Ender.Position = UDim2.new(0.00934579596, 0, 0.428352326, 0)
Ender.Size = UDim2.new(0, 419, 0, 36)
Ender.Font = Enum.Font.SourceSansBold
Ender.Text = "    Ender"
Ender.TextColor3 = Color3.fromRGB(255, 255, 255)
Ender.TextSize = 20.000
Ender.TextWrapped = true
Ender.TextXAlignment = Enum.TextXAlignment.Left

UICorner_31.Parent = Ender

BanHammer.Name = "BanHammer"
BanHammer.Parent = ScrollingFrame
BanHammer.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
BanHammer.Position = UDim2.new(0.00934579596, 0, 0.383384466, 0)
BanHammer.Size = UDim2.new(0, 419, 0, 36)
BanHammer.Font = Enum.Font.SourceSansBold
BanHammer.Text = "    Ban Hammer"
BanHammer.TextColor3 = Color3.fromRGB(255, 255, 255)
BanHammer.TextSize = 20.000
BanHammer.TextWrapped = true
BanHammer.TextXAlignment = Enum.TextXAlignment.Left

UICorner_32.Parent = BanHammer

Caducus.Name = "Caducus"
Caducus.Parent = ScrollingFrame
Caducus.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
Caducus.Position = UDim2.new(0.00934579596, 0, 0.459044695, 0)
Caducus.Size = UDim2.new(0, 419, 0, 36)
Caducus.Font = Enum.Font.SourceSansBold
Caducus.Text = "    Caducus"
Caducus.TextColor3 = Color3.fromRGB(255, 255, 255)
Caducus.TextSize = 20.000
Caducus.TextWrapped = true
Caducus.TextXAlignment = Enum.TextXAlignment.Left

UICorner_33.Parent = Caducus

AK47.Name = "AK47"
AK47.Parent = ScrollingFrame
AK47.BackgroundColor3 = Color3.fromRGB(250, 128, 114)
AK47.Position = UDim2.new(0.00934579596, 0, 0.245982587, 0)
AK47.Size = UDim2.new(0, 419, 0, 36)
AK47.Font = Enum.Font.SourceSansBold
AK47.Text = "    AK-47"
AK47.TextColor3 = Color3.fromRGB(255, 255, 255)
AK47.TextSize = 20.000
AK47.TextWrapped = true
AK47.TextXAlignment = Enum.TextXAlignment.Left

UICorner_34.Parent = AK47

Car.Name = "Car"
Car.Parent = ScrollingFrame
Car.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Car.Position = UDim2.new(0.00934579782, 0, 0.505083203, 0)
Car.Size = UDim2.new(0, 419, 0, 36)
Car.Font = Enum.Font.SourceSansBold
Car.Text = "    Dababy Car"
Car.TextColor3 = Color3.fromRGB(255, 255, 255)
Car.TextSize = 20.000
Car.TextWrapped = true
Car.TextXAlignment = Enum.TextXAlignment.Left

UICorner_35.Parent = Car

Carnage.Name = "Carnage"
Carnage.Parent = ScrollingFrame
Carnage.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Carnage.Position = UDim2.new(0.00934579782, 0, 0.520429432, 0)
Carnage.Size = UDim2.new(0, 419, 0, 36)
Carnage.Font = Enum.Font.SourceSansBold
Carnage.Text = "    Carnage"
Carnage.TextColor3 = Color3.fromRGB(255, 255, 255)
Carnage.TextSize = 20.000
Carnage.TextWrapped = true
Carnage.TextXAlignment = Enum.TextXAlignment.Left

UICorner_36.Parent = Carnage

MLG.Name = "MLG"
MLG.Parent = ScrollingFrame
MLG.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
MLG.Position = UDim2.new(0.00934579782, 0, 0.535775602, 0)
MLG.Size = UDim2.new(0, 419, 0, 36)
MLG.Font = Enum.Font.SourceSansBold
MLG.Text = "    MLG Gun"
MLG.TextColor3 = Color3.fromRGB(255, 255, 255)
MLG.TextSize = 20.000
MLG.TextWrapped = true
MLG.TextXAlignment = Enum.TextXAlignment.Left

UICorner_37.Parent = MLG

Pen.Name = "Pen"
Pen.Parent = ScrollingFrame
Pen.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Pen.Position = UDim2.new(0.00934579782, 0, 0.565397263, 0)
Pen.Size = UDim2.new(0, 419, 0, 36)
Pen.Font = Enum.Font.SourceSansBold
Pen.Text = "    Pen"
Pen.TextColor3 = Color3.fromRGB(255, 255, 255)
Pen.TextSize = 20.000
Pen.TextWrapped = true
Pen.TextXAlignment = Enum.TextXAlignment.Left

UICorner_38.Parent = Pen

Broomstick.Name = "Broomstick"
Broomstick.Parent = ScrollingFrame
Broomstick.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Broomstick.Position = UDim2.new(0.00934579782, 0, 0.596089661, 0)
Broomstick.Size = UDim2.new(0, 419, 0, 36)
Broomstick.Font = Enum.Font.SourceSansBold
Broomstick.Text = "    Broomstick"
Broomstick.TextColor3 = Color3.fromRGB(255, 255, 255)
Broomstick.TextSize = 20.000
Broomstick.TextWrapped = true
Broomstick.TextXAlignment = Enum.TextXAlignment.Left

UICorner_39.Parent = Broomstick

Memeus.Name = "Memeus"
Memeus.Parent = ScrollingFrame
Memeus.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Memeus.Position = UDim2.new(0.00934579782, 0, 0.550051093, 0)
Memeus.Size = UDim2.new(0, 419, 0, 36)
Memeus.Font = Enum.Font.SourceSansBold
Memeus.Text = "   Memeus"
Memeus.TextColor3 = Color3.fromRGB(255, 255, 255)
Memeus.TextSize = 20.000
Memeus.TextWrapped = true
Memeus.TextXAlignment = Enum.TextXAlignment.Left

UICorner_40.Parent = Memeus

Xester.Name = "Xester"
Xester.Parent = ScrollingFrame
Xester.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Xester.Position = UDim2.new(0.00934579782, 0, 0.580743492, 0)
Xester.Size = UDim2.new(0, 419, 0, 36)
Xester.Font = Enum.Font.SourceSansBold
Xester.Text = "    Xester"
Xester.TextColor3 = Color3.fromRGB(255, 255, 255)
Xester.TextSize = 20.000
Xester.TextWrapped = true
Xester.TextXAlignment = Enum.TextXAlignment.Left

UICorner_41.Parent = Xester

DistractDance.Name = "DistractDance"
DistractDance.Parent = ScrollingFrame
DistractDance.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
DistractDance.Position = UDim2.new(0.00934579782, 0, 0.687452972, 0)
DistractDance.Size = UDim2.new(0, 419, 0, 36)
DistractDance.Font = Enum.Font.SourceSansBold
DistractDance.Text = "    Distract Dance"
DistractDance.TextColor3 = Color3.fromRGB(255, 255, 255)
DistractDance.TextSize = 20.000
DistractDance.TextWrapped = true
DistractDance.TextXAlignment = Enum.TextXAlignment.Left

UICorner_42.Parent = DistractDance

Goopie.Name = "Goopie"
Goopie.Parent = ScrollingFrame
Goopie.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Goopie.Position = UDim2.new(0.00934579782, 0, 0.642485082, 0)
Goopie.Size = UDim2.new(0, 419, 0, 36)
Goopie.Font = Enum.Font.SourceSansBold
Goopie.Text = "    Goopie"
Goopie.TextColor3 = Color3.fromRGB(255, 255, 255)
Goopie.TextSize = 20.000
Goopie.TextWrapped = true
Goopie.TextXAlignment = Enum.TextXAlignment.Left

UICorner_43.Parent = Goopie

Headless.Name = "Headless"
Headless.Parent = ScrollingFrame
Headless.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Headless.Position = UDim2.new(0.00934579782, 0, 0.611792743, 0)
Headless.Size = UDim2.new(0, 419, 0, 36)
Headless.Font = Enum.Font.SourceSansBold
Headless.Text = "    Headless"
Headless.TextColor3 = Color3.fromRGB(255, 255, 255)
Headless.TextSize = 20.000
Headless.TextWrapped = true
Headless.TextXAlignment = Enum.TextXAlignment.Left

UICorner_44.Parent = Headless

OrangeJustice.Name = "OrangeJustice"
OrangeJustice.Parent = ScrollingFrame
OrangeJustice.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
OrangeJustice.Position = UDim2.new(0.00934579782, 0, 0.657831252, 0)
OrangeJustice.Size = UDim2.new(0, 419, 0, 36)
OrangeJustice.Font = Enum.Font.SourceSansBold
OrangeJustice.Text = "    Orange Justice"
OrangeJustice.TextColor3 = Color3.fromRGB(255, 255, 255)
OrangeJustice.TextSize = 20.000
OrangeJustice.TextWrapped = true
OrangeJustice.TextXAlignment = Enum.TextXAlignment.Left

UICorner_45.Parent = OrangeJustice

InsanityPowers.Name = "InsanityPowers"
InsanityPowers.Parent = ScrollingFrame
InsanityPowers.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
InsanityPowers.Position = UDim2.new(0.00934579782, 0, 0.718145311, 0)
InsanityPowers.Size = UDim2.new(0, 419, 0, 36)
InsanityPowers.Font = Enum.Font.SourceSansBold
InsanityPowers.Text = "    Insanity Powers"
InsanityPowers.TextColor3 = Color3.fromRGB(255, 255, 255)
InsanityPowers.TextSize = 20.000
InsanityPowers.TextWrapped = true
InsanityPowers.TextXAlignment = Enum.TextXAlignment.Left

UICorner_46.Parent = InsanityPowers

Floss.Name = "Floss"
Floss.Parent = ScrollingFrame
Floss.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Floss.Position = UDim2.new(0.00934579782, 0, 0.672106802, 0)
Floss.Size = UDim2.new(0, 419, 0, 36)
Floss.Font = Enum.Font.SourceSansBold
Floss.Text = "    Floss"
Floss.TextColor3 = Color3.fromRGB(255, 255, 255)
Floss.TextSize = 20.000
Floss.TextWrapped = true
Floss.TextXAlignment = Enum.TextXAlignment.Left

UICorner_47.Parent = Floss

HeadHold.Name = "HeadHold"
HeadHold.Parent = ScrollingFrame
HeadHold.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
HeadHold.Position = UDim2.new(0.00934579782, 0, 0.627138913, 0)
HeadHold.Size = UDim2.new(0, 419, 0, 36)
HeadHold.Font = Enum.Font.SourceSansBold
HeadHold.Text = "    Head Hold"
HeadHold.TextColor3 = Color3.fromRGB(255, 255, 255)
HeadHold.TextSize = 20.000
HeadHold.TextWrapped = true
HeadHold.TextXAlignment = Enum.TextXAlignment.Left

UICorner_48.Parent = HeadHold

RussainKick.Name = "RussainKick"
RussainKick.Parent = ScrollingFrame
RussainKick.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
RussainKick.Position = UDim2.new(0.00934579782, 0, 0.702799141, 0)
RussainKick.Size = UDim2.new(0, 419, 0, 36)
RussainKick.Font = Enum.Font.SourceSansBold
RussainKick.Text = "    Russain Kick"
RussainKick.TextColor3 = Color3.fromRGB(255, 255, 255)
RussainKick.TextSize = 20.000
RussainKick.TextWrapped = true
RussainKick.TextXAlignment = Enum.TextXAlignment.Left

UICorner_49.Parent = RussainKick

Pillow.Name = "Pillow"
Pillow.Parent = ScrollingFrame
Pillow.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Pillow.Position = UDim2.new(0.00934579782, 0, 0.764183879, 0)
Pillow.Size = UDim2.new(0, 419, 0, 36)
Pillow.Font = Enum.Font.SourceSansBold
Pillow.Text = "    Pillow"
Pillow.TextColor3 = Color3.fromRGB(255, 255, 255)
Pillow.TextSize = 20.000
Pillow.TextWrapped = true
Pillow.TextXAlignment = Enum.TextXAlignment.Left

UICorner_50.Parent = Pillow

Pp.Name = "Pp"
Pp.Parent = ScrollingFrame
Pp.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Pp.Position = UDim2.new(0.00934579782, 0, 0.779530048, 0)
Pp.Size = UDim2.new(0, 419, 0, 36)
Pp.Font = Enum.Font.SourceSansBold
Pp.Text = "    PP"
Pp.TextColor3 = Color3.fromRGB(255, 255, 255)
Pp.TextSize = 20.000
Pp.TextWrapped = true
Pp.TextXAlignment = Enum.TextXAlignment.Left

UICorner_51.Parent = Pp

BlackHole.Name = "BlackHole"
BlackHole.Parent = ScrollingFrame
BlackHole.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
BlackHole.Position = UDim2.new(0.00934579782, 0, 0.839844108, 0)
BlackHole.Size = UDim2.new(0, 419, 0, 36)
BlackHole.Font = Enum.Font.SourceSansBold
BlackHole.Text = "    Black Hole"
BlackHole.TextColor3 = Color3.fromRGB(255, 255, 255)
BlackHole.TextSize = 20.000
BlackHole.TextWrapped = true
BlackHole.TextXAlignment = Enum.TextXAlignment.Left

UICorner_52.Parent = BlackHole

JhonDoe.Name = "JhonDoe"
JhonDoe.Parent = ScrollingFrame
JhonDoe.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
JhonDoe.Position = UDim2.new(0.00934579782, 0, 0.85554719, 0)
JhonDoe.Size = UDim2.new(0, 419, 0, 36)
JhonDoe.Font = Enum.Font.SourceSansBold
JhonDoe.Text = "    Jhon Doe"
JhonDoe.TextColor3 = Color3.fromRGB(255, 255, 255)
JhonDoe.TextSize = 20.000
JhonDoe.TextWrapped = true
JhonDoe.TextXAlignment = Enum.TextXAlignment.Left

UICorner_53.Parent = JhonDoe

VR.Name = "VR"
VR.Parent = ScrollingFrame
VR.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
VR.Position = UDim2.new(0.00934579782, 0, 0.915861249, 0)
VR.Size = UDim2.new(0, 419, 0, 36)
VR.Font = Enum.Font.SourceSansBold
VR.Text = "    VR"
VR.TextColor3 = Color3.fromRGB(255, 255, 255)
VR.TextSize = 20.000
VR.TextWrapped = true
VR.TextXAlignment = Enum.TextXAlignment.Left

UICorner_54.Parent = VR

TouchKill.Name = "TouchKill"
TouchKill.Parent = ScrollingFrame
TouchKill.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
TouchKill.Position = UDim2.new(0.00934579782, 0, 0.809151709, 0)
TouchKill.Size = UDim2.new(0, 419, 0, 36)
TouchKill.Font = Enum.Font.SourceSansBold
TouchKill.Text = "    Touch Kill"
TouchKill.TextColor3 = Color3.fromRGB(255, 255, 255)
TouchKill.TextSize = 20.000
TouchKill.TextWrapped = true
TouchKill.TextXAlignment = Enum.TextXAlignment.Left

UICorner_55.Parent = TouchKill

TakeTheL.Name = "TakeTheL"
TakeTheL.Parent = ScrollingFrame
TakeTheL.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
TakeTheL.Position = UDim2.new(0.00934579782, 0, 0.824497938, 0)
TakeTheL.Size = UDim2.new(0, 419, 0, 36)
TakeTheL.Font = Enum.Font.SourceSansBold
TakeTheL.Text = "    Take The L"
TakeTheL.TextColor3 = Color3.fromRGB(255, 255, 255)
TakeTheL.TextSize = 20.000
TakeTheL.TextWrapped = true
TakeTheL.TextXAlignment = Enum.TextXAlignment.Left

UICorner_56.Parent = TakeTheL

Grabknife.Name = "Grab Knife"
Grabknife.Parent = ScrollingFrame
Grabknife.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Grabknife.Position = UDim2.new(0.00934579782, 0, 0.886239529, 0)
Grabknife.Size = UDim2.new(0, 419, 0, 36)
Grabknife.Font = Enum.Font.SourceSansBold
Grabknife.Text = "    Grab Knife 4"
Grabknife.TextColor3 = Color3.fromRGB(255, 255, 255)
Grabknife.TextSize = 20.000
Grabknife.TextWrapped = true
Grabknife.TextXAlignment = Enum.TextXAlignment.Left

UICorner_57.Parent = Grabknife

Rtx.Name = "Rtx"
Rtx.Parent = ScrollingFrame
Rtx.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Rtx.Position = UDim2.new(0.00934579782, 0, 0.901585698, 0)
Rtx.Size = UDim2.new(0, 419, 0, 36)
Rtx.Font = Enum.Font.SourceSansBold
Rtx.Text = "    RTX"
Rtx.TextColor3 = Color3.fromRGB(255, 255, 255)
Rtx.TextSize = 20.000
Rtx.TextWrapped = true
Rtx.TextXAlignment = Enum.TextXAlignment.Left

UICorner_58.Parent = Rtx

RainbowKing.Name = "RainbowKing"
RainbowKing.Parent = ScrollingFrame
RainbowKing.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
RainbowKing.Position = UDim2.new(0.00934579782, 0, 0.79380554, 0)
RainbowKing.Size = UDim2.new(0, 419, 0, 36)
RainbowKing.Font = Enum.Font.SourceSansBold
RainbowKing.Text = "    Rainbow King"
RainbowKing.TextColor3 = Color3.fromRGB(255, 255, 255)
RainbowKing.TextSize = 20.000
RainbowKing.TextWrapped = true
RainbowKing.TextXAlignment = Enum.TextXAlignment.Left

UICorner_59.Parent = RainbowKing

Gun.Name = "Gun"
Gun.Parent = ScrollingFrame
Gun.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Gun.Position = UDim2.new(0.00934579782, 0, 0.931207418, 0)
Gun.Size = UDim2.new(0, 419, 0, 36)
Gun.Font = Enum.Font.SourceSansBold
Gun.Text = "    Gun"
Gun.TextColor3 = Color3.fromRGB(255, 255, 255)
Gun.TextSize = 20.000
Gun.TextWrapped = true
Gun.TextXAlignment = Enum.TextXAlignment.Left

UICorner_60.Parent = Gun

PixelCar.Name = "PixelCar"
PixelCar.Parent = ScrollingFrame
PixelCar.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
PixelCar.Position = UDim2.new(0.00934579782, 0, 0.961899757, 0)
PixelCar.Size = UDim2.new(0, 419, 0, 36)
PixelCar.Font = Enum.Font.SourceSansBold
PixelCar.Text = "    Pixel Car"
PixelCar.TextColor3 = Color3.fromRGB(255, 255, 255)
PixelCar.TextSize = 20.000
PixelCar.TextWrapped = true
PixelCar.TextXAlignment = Enum.TextXAlignment.Left

UICorner_61.Parent = PixelCar

HellRobotics.Name = "HellRobotics"
HellRobotics.Parent = ScrollingFrame
HellRobotics.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
HellRobotics.Position = UDim2.new(0.00934579782, 0, 0.748837709, 0)
HellRobotics.Size = UDim2.new(0, 419, 0, 36)
HellRobotics.Font = Enum.Font.SourceSansBold
HellRobotics.Text = "    Hell Robotics"
HellRobotics.TextColor3 = Color3.fromRGB(255, 255, 255)
HellRobotics.TextSize = 20.000
HellRobotics.TextWrapped = true
HellRobotics.TextXAlignment = Enum.TextXAlignment.Left

UICorner_62.Parent = HellRobotics

Titain.Name = "Titain"
Titain.Parent = ScrollingFrame
Titain.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Titain.Position = UDim2.new(0.00934579782, 0, 0.946553588, 0)
Titain.Size = UDim2.new(0, 419, 0, 36)
Titain.Font = Enum.Font.SourceSansBold
Titain.Text = "    Titain"
Titain.TextColor3 = Color3.fromRGB(255, 255, 255)
Titain.TextSize = 20.000
Titain.TextWrapped = true
Titain.TextXAlignment = Enum.TextXAlignment.Left

UICorner_63.Parent = Titain

Neko.Name = "Neko"
Neko.Parent = ScrollingFrame
Neko.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Neko.Position = UDim2.new(0.00934579782, 0, 0.870893359, 0)
Neko.Size = UDim2.new(0, 419, 0, 36)
Neko.Font = Enum.Font.SourceSansBold
Neko.Text = "    Neko"
Neko.TextColor3 = Color3.fromRGB(255, 255, 255)
Neko.TextSize = 20.000
Neko.TextWrapped = true
Neko.TextXAlignment = Enum.TextXAlignment.Left

UICorner_64.Parent = Neko

Zen.Name = "Zen"
Zen.Parent = ScrollingFrame
Zen.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Zen.Position = UDim2.new(0.00934579782, 0, 0.73349148, 0)
Zen.Size = UDim2.new(0, 419, 0, 36)
Zen.Font = Enum.Font.SourceSansBold
Zen.Text = "    Zen"
Zen.TextColor3 = Color3.fromRGB(255, 255, 255)
Zen.TextSize = 20.000
Zen.TextWrapped = true
Zen.TextXAlignment = Enum.TextXAlignment.Left

UICorner_65.Parent = Zen

Minigun.Name = "Minigun"
Minigun.Parent = ScrollingFrame
Minigun.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Minigun.Position = UDim2.new(0.00934579782, 0, 0.489737064, 0)
Minigun.Size = UDim2.new(0, 419, 0, 36)
Minigun.Font = Enum.Font.SourceSansBold
Minigun.Text = "    Dev Uzi"
Minigun.TextColor3 = Color3.fromRGB(255, 255, 255)
Minigun.TextSize = 20.000
Minigun.TextWrapped = true
Minigun.TextXAlignment = Enum.TextXAlignment.Left

UICorner_66.Parent = Minigun

Eggdog.Name = "Eggdog"
Eggdog.Parent = ScrollingFrame
Eggdog.BackgroundColor3 = Color3.fromRGB(170, 0, 255)
Eggdog.Position = UDim2.new(0.00934579782, 0, 0.977602839, 0)
Eggdog.Size = UDim2.new(0, 419, 0, 36)
Eggdog.Font = Enum.Font.SourceSansBold
Eggdog.Text = "    Eggdog"
Eggdog.TextColor3 = Color3.fromRGB(255, 255, 255)
Eggdog.TextSize = 20.000
Eggdog.TextWrapped = true
Eggdog.TextXAlignment = Enum.TextXAlignment.Left

UICorner_67.Parent = Eggdog

Credits.Name = "Credits"
Credits.Parent = Main
Credits.BackgroundColor3 = Color3.fromRGB(4, 179, 7)
Credits.BorderSizePixel = 0
Credits.Position = UDim2.new(0.0223718882, 0, 0.834973812, 0)
Credits.Size = UDim2.new(0, 428, 0, 36)
Credits.Font = Enum.Font.SourceSans
Credits.Text = "Created by YepImSirPwnsAlot & Retarded_Dummy."
Credits.TextColor3 = Color3.fromRGB(255, 255, 255)
Credits.TextSize = 23.000
Credits.TextWrapped = true

UICorner_68.CornerRadius = UDim.new(1, 0)
UICorner_68.Parent = Credits

Respawn.Name = "Respawn"
Respawn.Parent = Main
Respawn.BackgroundColor3 = Color3.fromRGB(119, 221, 119)
Respawn.Position = UDim2.new(0.72, 0, 0.915730357, 0)
Respawn.Size = UDim2.new(0, 115, 0, 35)
Respawn.Font = Enum.Font.SourceSansBold
Respawn.Text = "Respawn"
Respawn.TextColor3 = Color3.fromRGB(0,128,0)
Respawn.TextSize = 30

UICorner_69.CornerRadius = UDim.new(1, 0)
UICorner_69.Parent = Respawn

Netless.Name = "Netless"
Netless.Parent = Main
Netless.BackgroundColor3 = Color3.fromRGB(4, 179, 7)
Netless.Position = UDim2.new(0.323725045, 0, 0.915730357, 0)
Netless.Size = UDim2.new(0, 152, 0, 36)
Netless.Font = Enum.Font.SourceSansBold
Netless.Text = "Netless (USE AFTER SCRIPTS)"
Netless.TextColor3 = Color3.fromRGB(0, 0, 0)
Netless.TextScaled = true
Netless.TextSize = 14.000
Netless.TextWrapped = true
Netless.Visible = false

UICorner_70.Parent = Netless

AntiFling.Name = "AntiFling"
AntiFling.Parent = Main
AntiFling.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
AntiFling.Position = UDim2.new(0.0245891828, 0, 0.915730357, 0)
AntiFling.Size = UDim2.new(0, 305, 0, 35)
AntiFling.Font = Enum.Font.SourceSansBold
AntiFling.Text = "Me"
AntiFling.TextColor3 = Color3.fromRGB(0, 0, 0)
AntiFling.TextScaled = true
AntiFling.TextSize = 14.000
AntiFling.TextWrapped = true

UICorner_71.CornerRadius = UDim.new(1, 0)
UICorner_71.Parent = AntiFling

X.Name = "X"
X.Parent = Main
X.BackgroundColor3 = Color3.fromRGB(247, 114, 99)
X.Position = UDim2.new(0.93569845, 0, -0.0337078646, 0)
X.Size = UDim2.new(0, 50, 0, 50)
X.Font = Enum.Font.SourceSansBold
X.Text = "X"
X.TextColor3 = Color3.fromRGB(255, 255, 255)
X.TextScaled = true
X.TextSize = 14.000
X.TextWrapped = true
X.MouseButton1Down:Connect(function()
	Main.Visible = false
	OpenUtg.Visible = true
end)

UICorner_72.CornerRadius = UDim.new(1, 0)
UICorner_72.Parent = X

OpenUtg.Name = "OpenUtg"
OpenUtg.Parent = UltimateTrollingGuiV6
OpenUtg.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
OpenUtg.BackgroundTransparency = 1.000
OpenUtg.Position = UDim2.new(0.816202641, 0, 0.817640007, 0)
OpenUtg.Size = UDim2.new(0, 200, 0, 50)
OpenUtg.Visible = false
OpenUtg.Font = Enum.Font.SourceSansBold
OpenUtg.Text = "UTG"
OpenUtg.TextColor3 = Color3.fromRGB(255, 255, 255)
OpenUtg.TextStrokeColor3 = Color3.fromRGB(255, 0, 0)
OpenUtg.TextStrokeTransparency = 0
OpenUtg.TextScaled = true
OpenUtg.TextSize = 20

subtext.Name = "SubText"
subtext.Parent = OpenUtg
subtext.BackgroundTransparency = 1
subtext.Position = UDim2.new(0, 0, 1, -10)
subtext.Size = UDim2.new(1, 0, 0, 20)
subtext.Font = Enum.Font.SourceSansBold
subtext.Text = "CLICK TO TOGGLE"
subtext.TextColor3 = Color3.fromRGB(255, 255, 255)
subtext.TextStrokeColor3 = Color3.fromRGB(255, 0, 0)
subtext.TextStrokeTransparency = 0
subtext.TextScaled = true

OpenUtg.MouseButton1Down:Connect(function()
	Main.Visible = true
	OpenUtg.Visible = false
end)

task.spawn(function()
	local colors = {
		Color3.fromRGB(255, 0, 0),     -- Red
		Color3.fromRGB(255, 255, 0),   -- Yellow
		Color3.fromRGB(0, 0, 255),     -- Blue
		Color3.fromRGB(128, 0, 128),   -- Purple
		Color3.fromRGB(255, 165, 0),   -- Orange
		Color3.fromRGB(0, 255, 0),     -- Green
		Color3.fromRGB(255, 51, 153)  -- Pink
	}


	while true do
		local currentColor = colors[currentIndex]
		local nextColor = colors[nextIndex]

		for step = 0, 1, 0.02 do
			local lerped = currentColor:Lerp(nextColor, step)
			OpenUtg.TextStrokeColor3 = lerped
			subtext.TextStrokeColor3 = lerped
			wait(0.03)
		end

		currentIndex = nextIndex
		nextIndex = (nextIndex % #colors) + 1
	end
end)

local function MakeDraggable()
	local UIS = game:GetService('UserInputService')
	local frame = Main
	local dragToggle = false
	local dragSpeed = 0.25
	local dragStart = nil
	local startPos = nil

	local function updateInput(input)
		local delta = input.Position - dragStart
		local position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X,
			startPos.Y.Scale, startPos.Y.Offset + delta.Y)
		game:GetService('TweenService'):Create(frame, TweenInfo.new(dragSpeed), {Position = position}):Play()
	end

	frame.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragToggle = true
			dragStart = input.Position
			startPos = frame.Position

			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)

	UIS.InputChanged:Connect(function(input)
		if (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) and dragToggle then
			updateInput(input)
		end
	end)
end
MakeDraggable()

Main:TweenPosition(UDim2.new(0.382, 0, 0.181, 0), "Out", "Quad", 0.5, true)
