loadstring(game:HttpGet("https://pastebin.com/raw/q6yHJSXK", true))()
