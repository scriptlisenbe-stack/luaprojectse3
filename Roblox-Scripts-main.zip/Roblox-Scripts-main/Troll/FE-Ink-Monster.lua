loadstring(game:HttpGet("https://pastebin.com/raw/RvrJsRX9"))() --Mainly mobile support semi support for PC
