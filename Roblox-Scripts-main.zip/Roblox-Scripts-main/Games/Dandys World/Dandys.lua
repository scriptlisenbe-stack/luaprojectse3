loadstring(game:HttpGet("http://lumin-hub.lol/Dandys.lua"))()
