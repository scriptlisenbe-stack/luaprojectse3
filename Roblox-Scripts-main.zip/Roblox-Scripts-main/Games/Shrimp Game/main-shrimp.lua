loadstring(game:HttpGet('https://gist.githubusercontent.com/depthso/134e1b8a78e0248f0c1a9e03e5329e26/raw/785672355b38deb7b1d22d13a6e5ecdb7bb0febb/Method.lua'))()
