loadstring(game:HttpGet("https://github.com/s-0-u-l-z/Roblox-Scripts/blob/main/Obsfucate/EZ.lua", true))()
