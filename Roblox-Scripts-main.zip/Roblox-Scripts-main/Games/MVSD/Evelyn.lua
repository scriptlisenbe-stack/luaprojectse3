loadstring(game:HttpGet("https://raw.githubusercontent.com/evelynnscripts/Scripts/refs/heads/main/Loader.lua",true))()
