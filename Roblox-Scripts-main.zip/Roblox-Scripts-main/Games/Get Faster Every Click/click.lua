loadstring(game:HttpGet("https://raw.githubusercontent.com/Adhruio/getfastereveryclick/refs/heads/master/scriptprotected"))()

--[[
																		 _
																		(_)
																		 \\     ((   
 __           ______                                                 __   \\     ))  WARNING: This Script Is LUA PROTECTED.
|  \         /      \                                               |  \   \\   ((   !!!NOTE!!!: Use the script at the lua protected code stealing, Code Stealing May Provide Stealing The Code and Changing it.
 \▓▓_______ |  ▓▓▓▓▓▓\      _______  ______   ______   ______   ____| ▓▓    \\   ))  HAPPY SCRIPTING!!! 😊😊😊
|  \       \| ▓▓_  \▓▓     /       \/      \ /      \ /      \ /      ▓▓    //  ((   #2 Note: I Grabbed This ASCII Art From https://texteditor.com/multiline-text-art/. have fun, ig
| ▓▓ ▓▓▓▓▓▓▓\ ▓▓ \        |  ▓▓▓▓▓▓▓  ▓▓▓▓▓▓\  ▓▓▓▓▓▓\  ▓▓▓▓▓▓\  ▓▓▓▓▓▓▓   //    ))  i created this Script to Support Calmness and relaxation!
| ▓▓ ▓▓  | ▓▓ ▓▓▓▓         \▓▓    \| ▓▓  | ▓▓ ▓▓    ▓▓ ▓▓    ▓▓ ▓▓  | ▓▓  //    ((   #3 Note: Changing The Number for inf speed, may cause to crash OR/AND Lag. 
| ▓▓ ▓▓  | ▓▓ ▓▓           _\▓▓▓▓▓▓\ ▓▓__/ ▓▓ ▓▓▓▓▓▓▓▓ ▓▓▓▓▓▓▓▓ ▓▓__| ▓▓ //      ))  #4 Note: execute as much as you want!! (READ THE 3RD NOTE FIRST!!)
| ▓▓ ▓▓  | ▓▓ ▓▓          |       ▓▓ ▓▓    ▓▓\▓▓     \\▓▓     \\▓▓    ▓▓ \\     ((   Credits: Special Thanks to YOU!!!😀
 \▓▓\▓▓   \▓▓\▓▓           \▓▓▓▓▓▓▓| ▓▓▓▓▓▓▓  \▓▓▓▓▓▓▓ \▓▓▓▓▓▓▓ \▓▓▓▓▓▓▓  \\     ))  Aura From RScripts: Merge For SPEED!⚡ script,
                                   | ▓▓                                    \\   ((   Clickzz For The Game.
                                   | ▓▓                                     \\   ))  
                                    \▓▓                                     (_)  
]]
