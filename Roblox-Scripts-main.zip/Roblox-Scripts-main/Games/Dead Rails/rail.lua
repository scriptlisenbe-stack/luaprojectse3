loadstring(game:HttpGet("https://pastefy.app/ULaWpxKm/raw"))()
