loadstring(game:HttpGet("https://get-avth-ontop.netlify.app/my-paste/script.lua"))()
