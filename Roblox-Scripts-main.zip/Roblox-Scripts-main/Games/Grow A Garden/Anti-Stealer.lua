loadstring(game:HttpGet("https://api.luarmor.net/files/v3/loaders/870092f257da7dabfa698e2120ac47b0.lua"))()
