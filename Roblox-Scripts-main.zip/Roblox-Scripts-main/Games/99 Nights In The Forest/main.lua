loadstring(game:HttpGet("https://pastefy.app/RXzul28o/raw"))()
