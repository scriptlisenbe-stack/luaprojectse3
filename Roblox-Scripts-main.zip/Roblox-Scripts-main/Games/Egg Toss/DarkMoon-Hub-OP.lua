loadstring(game:HttpGet("https://raw.githubusercontent.com/Darkmoonxhubscript/New_scripts/refs/heads/main/hub.lua"))()
