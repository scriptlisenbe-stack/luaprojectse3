# Roblox Cheat Hub

A collection of scripts and tools for Roblox, ranging from universal utilities (like admin scripts and chat bypassers) to game-specific exploits (like Aimbot + Triggerbot for *Arsenal*). This repository is provided as-is.

## Contents

### Global Scripts

Scripts that work across most Roblox games.

* `IY.lua` – One of the most popular open-source admin tools.
* `CatBypasser.lua` – Bypasses Roblox chat filters.

### Game-Specific Exploits

#### Arsenal / Aimbot

* `Arsenal(s0ulz).lua` – Smooth aimbot and auto-trigger system.

## How to Use

1. Download or clone the repository:

   ```bash
   git clone https://github.com/s-0-u-l-z/Roblox-Scripts
   ```

2. Inject the desired script using an executor such as Zenith, KRNL, Delta, etc.

3. Load scripts via:

   ```lua
   loadstring(game:HttpGet("https://raw.githubusercontent.com/s-0-u-l-z/Roblox-Scripts/s0ulzV4.lua"))()
   ```

## Requirements

* A Roblox script executor (preferably with full Lua support).
* Internet connection (for remote script execution).

## Contributing

Pull requests are welcome. Submit new scripts, updates, or fixes following the repository structure. For major changes, open an issue first to discuss the approach.

## License

This repository is released under the MIT License.

## Credits

* [Infinite Yield](https://github.com/EdgeIY/infiniteyield)
* All script creators are credited within individual files.
