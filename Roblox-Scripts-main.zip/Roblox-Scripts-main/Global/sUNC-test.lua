--[[
   It would be so ironic if your executor couldn't exec this :)
   (Execute the source by copy pasting the raw)
]]

loadstring(game:HttpGet("https://raw.githubusercontent.com/HummingBird8/HummingRn/main/sUNCTestGET"))()
