-- My server: https://discord.gg/Nzy9gzSFYM
 
-- Made by @fuckluau
loadstring(game:HttpGet("https://sentinelxyz.netlify.app/raw.lua"))()
 
-- Their server: https://discord.gg/WxczCDGSFc
