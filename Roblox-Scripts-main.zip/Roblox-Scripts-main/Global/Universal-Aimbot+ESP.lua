loadstring(game:HttpGet("https://raw.githubusercontent.com/No6No6No7yt/Lumin-Hub/main/Universal.lua"))()  ```

-- For mobile https://pastebin.com/raw/h4iCWNy7