loadstring(game:HttpGet("https://zxfolix.github.io/antiafk.lua"))()
