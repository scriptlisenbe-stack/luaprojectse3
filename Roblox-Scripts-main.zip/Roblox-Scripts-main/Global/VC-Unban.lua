voiceChatService = game:GetService("VoiceChatService")
voiceChatService:joinVoice()
