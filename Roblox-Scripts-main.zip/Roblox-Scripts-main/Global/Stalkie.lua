--USE AT YOUR OWN RISK
--JOIN MY SERVER!! https://discord.gg/Nzy9gzSFYM
 
repeat task.wait() until game.Players.LocalPlayer
loadstring(game:HttpGet("https://raw.githubusercontent.com/0riginalWarrior/Stalkie/refs/heads/main/roblox.lua"))()
 
--Current Key: pizza
 
--Their Discord: https://discord.com/invite/N9yJV6357C