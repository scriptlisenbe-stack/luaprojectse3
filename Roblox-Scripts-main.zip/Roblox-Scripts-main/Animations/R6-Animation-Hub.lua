--[[
  Version: 1
  Made by: Fsploit/Eternal_w1nteriris


  Credit to the netless owner.
  Join our discord (.gg/getfrost)
]]--

loadstring(game:HttpGet("https://raw.githubusercontent.com/Fsploit/FeAnimationHub/refs/heads/main/Hub.lua"))()
