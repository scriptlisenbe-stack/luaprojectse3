loadstring(game:HttpGet("https://raw.githubusercontent.com/Dhelann/Dhelirium/refs/heads/main/source.lua"))()
