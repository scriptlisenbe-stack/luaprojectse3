# LE-C
Open Source Lua-C script executor and UI 
![1](https://user-images.githubusercontent.com/94013833/141225882-f0fa74e1-2fbd-4090-b638-c2ad790bc806.PNG)
