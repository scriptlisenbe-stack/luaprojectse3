# LONG TIME UNMAINTAINED AND NOT SUPPORTED!!!
## This was my very first project with VS and Windows Forms. This script is NOT working anymore and I will NOT continue developing it for the following reasons:
1. Roblox cheating scene is dead
2. Like I said: It was my first project and I only made it to learn something new
3. The API is also dead and DETECTED
4. Roblox started implementing their own AntiCheat, so most of the executors won't work anyway

![image](https://user-images.githubusercontent.com/76164598/164978039-8194918e-7634-4824-a40a-058b2c9ebbe7.png)


# About Neverwhere 👩‍💻
<br>
Neverwhere is a Open-Source, lightweight script injector and executor for Roblox. It's written in C# and it's being actively developed!
<br>
Checkout our custom API at https://github.com/WooxHimself/NeverwhereAPI <br>
Based on EasyXPloits

# How to download? 📩

1. Go to http://neverwhere.xyz to download it <br>
2. Unzip the .rar file, I recommend in Documents Folder or on your Desktop <br>
3. Launch NEVERWHERE.exe <br>
4. Wait for it to load <br>
5. Now you can use NEVERWHERE! <br>

<br>

# How to use it?  🚀
<br>
When you first launch NEVERWHERE, you might be a little bit confused, especially if it's your first time doing roblox exploiting.
<br> But don't worry, I will help you and guide you through!

### Buttons
Our UI has **5** main buttons<br>

**INJECT** -- Injects the selected script to the game<br>
**EXEC** -- Executes the injected script<br>
**CLEAR** -- Clears the script input<br>
**OPEN** -- Opens a script. Use .txt or .lua files<br>
**SAVE** -- Saves script in input
<br>

Then there are 3 other buttons:<br>

**USAGE** -- Shows you this README<br>
**SUPPORT** -- Invites you to our support server<br>
**RELOAD** -- Reloads the Scripts folder<br>

<br>

# How do I add my own script(s)? 📄
<br>
If you want to add your own script(s), just paste or create a .txt or .lua file in the Scripts/ folder along with the executable. <br>
Make sure the file contains the actual script.
<br>

If you don't see a Scripts folder, create one. Make sure it has capital S

# Possible issues ❗
<br>

### Freezing or Crashing

If your game freezes or crashes, it's because your injected script is outdated, bugged or doesn't contain LUA script <br>

### Getting Banned

If you got banned from minigame, or your whole account got banned, it's because you used your script very obviously. <br>

<br>

# How to stay safe 🌌

<br>

### Don't make your scripts too obvious. <br>
If you hop into let's say Arsenal game, and start spinning and one-tapping everyone, you're most likely getting banned.
<br>
### Don't tell everyone that you're using scripts/executors <br>
Do not tell in chat that you use scripts, do not show the executor/scripts on on example Discord Streams. Just try not to show it <br>
### Do not use random scripts <br>
Always check the code by yourself, if it doesn't contain malicous code. <br>
If you don't know coding and cannot read the source file, use our Script Hub or #scripts channel on our discord, or search on trustworthy sites/forums <br>
